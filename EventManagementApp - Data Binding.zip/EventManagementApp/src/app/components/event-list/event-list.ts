import { Component } from '@angular/core';
import { PriceFormatPipe } from '../../pipes/price-format-pipe';
import { CommonModule, DatePipe } from '@angular/common';
import { Highlight } from '../../directives/highlight';

@Component({
  selector: 'event-list',
  standalone: true,
  templateUrl: './event-list.html',
  styleUrls: ['./event-list.css'],
  imports: [CommonModule, PriceFormatPipe, DatePipe, Highlight]
})
export class EventList {
  events = [
    { name: 'Tech Innovators Conference', date: new Date('2025-09-12'), price: 3500, category: 'Conference' },
    { name: 'Creative Writing Workshop', date: new Date('2025-10-05'), price: 800, category: 'Workshop' },
    { name: 'Rock Music Concert', date: new Date('2025-11-20'), price: 2500, category: 'Concert' },
    { name: 'AI & Machine Learning Summit', date: new Date('2025-12-02'), price: 5000, category: 'Conference' }
  ];
}