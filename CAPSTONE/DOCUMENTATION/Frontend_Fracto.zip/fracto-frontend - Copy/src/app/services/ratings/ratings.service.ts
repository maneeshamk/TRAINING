// src/app/services/ratings/ratings.service.ts
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RatingService {
  private apiUrl = 'http://localhost:5005/api/Ratings';

  constructor(private http: HttpClient) {}

  private authOptions() {
    const token = localStorage.getItem('token') || '';
    return {
      headers: new HttpHeaders({
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      })
    };
  }

  // Admin-only - get all ratings
  getRatings(): Observable<any[]> {
    return this.http.get<any[]>(this.apiUrl, this.authOptions());
  }

  // Public - get ratings for a doctor
  getRatingsByDoctor(doctorId: number): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/doctor/${doctorId}`);
  }

  // Get the logged-in user's ratings (needs auth)
  getMyRatings(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/my`, this.authOptions());
  }

  // Submit a new rating (User role)
  submitRating(payload: { doctorId: number, ratingValue: number, comment?: string }): Observable<any> {
    // backend expects CreateRatingDto: doctorId, ratingValue (comment optional if DTO supports it)
    return this.http.post<any>(this.apiUrl, payload, this.authOptions());
  }

  // Update a rating (user)
  updateRating(id: number, payload: { ratingValue: number }): Observable<any> {
    return this.http.put<any>(`${this.apiUrl}/${id}`, payload, this.authOptions());
  }

  // Admin delete
  deleteRating(id: number): Observable<any> {
    return this.http.delete<any>(`${this.apiUrl}/${id}`, this.authOptions());
  }
}
