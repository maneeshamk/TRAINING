// src/app/services/user/user.service.ts
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private apiUrl = 'http://localhost:5005/api/Users';

  constructor(private http: HttpClient) {}

  private authOptions() {
    const token = localStorage.getItem('token') || '';
    return {
      headers: new HttpHeaders({
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json'
      })
    };
  }

  // GET /api/Users
  getUsers(): Observable<any[]> {
    return this.http.get<any[]>(this.apiUrl, this.authOptions());
  }

  // GET /api/Users/{id}
  getUser(id: number): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/${id}`, this.authOptions());
  }

  // POST /api/Users
  createUser(user: any): Observable<any> {
    return this.http.post<any>(this.apiUrl, user, this.authOptions());
  }

  // PUT /api/Users/{id}
  updateUser(id: number, user: any): Observable<any> {
    return this.http.put<any>(`${this.apiUrl}/${id}`, user, this.authOptions());
  }

  // PUT /api/Users/{id}/role
  changeRole(userId: number, role: string): Observable<any> {
    return this.http.put<any>(
      `${this.apiUrl}/${userId}/role`,
      { role },
      this.authOptions()
    );
  }

  // DELETE /api/Users/{id}
  deleteUser(id: number): Observable<any> {
    return this.http.delete<any>(`${this.apiUrl}/${id}`, this.authOptions());
  }

  // ✅ UPLOAD avatar: POST /api/Users/{id}/upload-avatar
  uploadAvatar(userId: number, file: File): Observable<any> {
    const formData = new FormData();
    formData.append('file', file); // backend expects "file"

    const token = localStorage.getItem('token') || '';
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`
      // ⚠️ Don't set Content-Type here; browser will auto-set multipart boundary
    });

    return this.http.post<any>(
      `${this.apiUrl}/${userId}/upload-avatar`,
      formData,
      { headers }
    );
  }
}
