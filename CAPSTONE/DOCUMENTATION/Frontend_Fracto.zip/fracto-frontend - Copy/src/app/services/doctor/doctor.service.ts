// src/app/services/doctor/doctor.service.ts
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DoctorService {
  private apiUrl = 'http://localhost:5005/api/Doctors';

  constructor(private http: HttpClient) {}

  private getAuthHeaders() {
    const token = localStorage.getItem('token') || '';
    return {
      headers: new HttpHeaders({
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json'
      })
    };
  }

  // Public endpoints
  getDoctors(): Observable<any[]> {
    return this.http.get<any[]>(this.apiUrl);
  }

  getDoctor(id: number): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/${id}`);
  }

  getDoctorsBySpecialization(specializationId: number): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/specialization/${specializationId}`);
  }

  getDoctorsByCity(city: string): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/city/${city}`);
  }

  // Admin-only endpoints (use auth headers)
  createDoctor(doctor: any): Observable<any> {
    return this.http.post<any>(this.apiUrl, doctor, this.getAuthHeaders());
  }

  updateDoctor(id: number, doctor: any): Observable<any> {
    return this.http.put<any>(`${this.apiUrl}/${id}`, doctor, this.getAuthHeaders());
  }

  deleteDoctor(id: number): Observable<any> {
    return this.http.delete<any>(`${this.apiUrl}/${id}`, this.getAuthHeaders());
  }
}
