import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-appointment-book',
  standalone: false,
  templateUrl: './appointment-book.html',
  styleUrls: ['./appointment-book.css']
})
export class AppointmentBook implements OnInit {
  doctorId: number = 0;
  appointmentDate: string = '';
  timeSlot: string = '';
  availableSlots: string[] = [];

  apiUrl = 'http://localhost:5005/api/Appointments';

  // slot settings
  private slotIntervalMinutes = 30;
  private workStart = '09:00';
  private workEnd = '17:00';

  // UI state
  submitting: boolean = false;
  errorMessage: string = '';
  successMessage: string = '';

  constructor(
    private route: ActivatedRoute,
    private http: HttpClient,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.doctorId = Number(this.route.snapshot.queryParamMap.get('doctorId')) || 0;
    this.availableSlots = this.generateDailySlots(this.workStart, this.workEnd, this.slotIntervalMinutes);
  }

  // generate daily slots (e.g., 09:00 - 09:30, 09:30 - 10:00...)
  private generateDailySlots(startTime: string, endTime: string, intervalMinutes: number): string[] {
    const slots: string[] = [];
    const [sh, sm] = startTime.split(':').map(Number);
    const [eh, em] = endTime.split(':').map(Number);

    let cur = new Date();
    cur.setHours(sh, sm, 0, 0);
    const end = new Date();
    end.setHours(eh, em, 0, 0);

    while (cur < end) {
      const startStr = this.formatTime(cur);
      const next = new Date(cur.getTime() + intervalMinutes * 60000);
      const endStr = this.formatTime(next);
      slots.push(`${startStr} - ${endStr}`);
      cur = next;
    }
    return slots;
  }

  private formatTime(d: Date): string {
    const hh = d.getHours().toString().padStart(2, '0');
    const mm = d.getMinutes().toString().padStart(2, '0');
    return `${hh}:${mm}`;
  }

  bookAppointment(): void {
    this.errorMessage = '';
    this.successMessage = '';

    if (!this.doctorId || !this.appointmentDate || !this.timeSlot) {
      this.errorMessage = 'Please select a date and time slot.';
      return;
    }

    const token = localStorage.getItem('token');
    if (!token) {
      this.errorMessage = 'You must be logged in to book an appointment.';
      return;
    }

    this.submitting = true;

    const startTime = this.timeSlot.split(' - ')[0]; // take start of slot
    const appointmentDateTime = new Date(`${this.appointmentDate}T${startTime}:00`).toISOString();

    const body = {
      doctorId: this.doctorId,
      appointmentDate: appointmentDateTime,
      timeSlot: this.timeSlot,
      status: 'booked'
    };

    this.http.post(this.apiUrl, body, {
      headers: { Authorization: `Bearer ${token}` }
    }).subscribe({
      next: () => {
        this.submitting = false;
        this.successMessage = 'Appointment booked successfully.';
        // redirect after short pause so user sees success message
        setTimeout(() => this.router.navigate(['/appointments-list']), 800);
      },
      error: (err: any) => {
        this.submitting = false;
        console.error('❌ Error booking appointment', err);
        // show backend message if available
        this.errorMessage = err?.error || 'Booking failed. Try another slot or refresh.';
      }
    });
  }

  // Called by Cancel button in template
  cancel(): void {
    // clear form and go back to user dashboard
    this.appointmentDate = '';
    this.timeSlot = '';
    this.errorMessage = '';
    this.successMessage = '';
    this.router.navigate(['/user-dashboard']);
  }
}
