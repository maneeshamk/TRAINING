import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-appointments-list',
  templateUrl: './appointments-list.html',
  standalone:false,
  styleUrls: ['./appointments-list.css'],
})
export class AppointmentsList implements OnInit {
  appointments: any[] = [];
  errorMessage: string = '';
  private apiUrl = 'http://localhost:5005/api/Appointments';

  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.loadAppointments();
  }

  loadAppointments() {
    const token = localStorage.getItem('token');
    const userId = localStorage.getItem('userId'); // 👈 ensure you store this at login

    this.http.get<any[]>(`${this.apiUrl}/user/${userId}`, {
      headers: { Authorization: `Bearer ${token}` }
    }).subscribe({
      next: (data) => this.appointments = data,
      error: (err) => this.errorMessage = 'Failed to load appointments'
    });
  }

  // 👇 Add this method to fix the error
  cancelAppointment(appointmentId: number) {
    const token = localStorage.getItem('token');

    this.http.put(`${this.apiUrl}/${appointmentId}/cancel`, {}, {
      headers: { Authorization: `Bearer ${token}` }
    }).subscribe({
      next: () => {
        console.log('✅ Appointment cancelled');
        this.loadAppointments(); // reload after cancel
      },
      error: (err) => {
        console.error('❌ Cancel failed', err);
        this.errorMessage = 'Unable to cancel appointment';
      }
    });
  }
}
