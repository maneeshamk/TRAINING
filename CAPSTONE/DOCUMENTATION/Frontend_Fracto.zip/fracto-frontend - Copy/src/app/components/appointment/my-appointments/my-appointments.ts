// my-appointments.component.ts
import { Component, OnInit } from '@angular/core';
import { AppointmentService } from '../../../services/appointment/appointment.service';

@Component({
  selector: 'app-my-appointments',
  standalone: false,
  templateUrl: './my-appointments.html',
  styleUrls: ['./my-appointments.css']
})
export class MyAppointments implements OnInit {
  appointments: any[] = [];

  constructor(private appointmentService: AppointmentService) {}

  ngOnInit() {
    this.loadMyAppointments();
  }

  loadMyAppointments() {
    // ✅ Get userId directly from localStorage (saved during login)
    const userId = localStorage.getItem('userId');

    if (userId) {
      this.appointmentService.getAppointmentsByUser(+userId).subscribe({
        next: (data: any[]) => this.appointments = data,
        error: (err: any) => console.error('Error loading appointments:', err)
      });
    } else {
      console.warn('⚠️ No userId found in localStorage. Did you login?');
    }
  }

  cancelAppointment(appointmentId: number) {
    if (confirm('Are you sure you want to cancel this appointment?')) {
      this.appointmentService.cancelAppointment(appointmentId).subscribe({
        next: () => {
          alert('Appointment cancelled successfully');
          this.loadMyAppointments(); // Reload list
        },
        error: (err: any) => {
          console.error('Error cancelling appointment:', err);
          alert('Failed to cancel appointment');
        }
      });
    }
  }
}
