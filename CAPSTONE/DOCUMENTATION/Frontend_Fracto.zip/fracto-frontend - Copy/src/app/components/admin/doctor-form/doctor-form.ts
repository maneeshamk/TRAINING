import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { DoctorService } from '../../../services/doctor/doctor.service';

@Component({
  selector: 'app-doctor-form',
  standalone:false,
  templateUrl: './doctor-form.html',
  styleUrls: ['./doctor-form.css']
})
export class DoctorForm implements OnInit {
  @Input() doctor: any = null; // null => create
  @Input() specializations: any[] = [];
  @Output() saved = new EventEmitter<void>();

  model: any = { name: '', specializationId: 0, city: '', rating: 0 };
  saving = false;
  error = '';

  constructor(private doctorService: DoctorService) {}

  ngOnInit(): void {
    if (this.doctor) {
      this.model = { ...this.doctor };
    }
  }

  save() {
    this.error = '';
    this.saving = true;

    if (this.doctor && this.doctor.doctorId) {
      this.doctorService.updateDoctor(this.doctor.doctorId, this.model).subscribe({
        next: () => { this.saving = false; this.saved.emit(); },
        error: (err: any) => { this.saving = false; this.error = 'Update failed'; console.error(err); }
      });
    } else {
      this.doctorService.createDoctor(this.model).subscribe({
        next: () => { this.saving = false; this.saved.emit(); },
        error: (err: any) => { this.saving = false; this.error = 'Create failed'; console.error(err); }
      });
    }
  }

  cancel() {
    this.saved.emit(); // simply close form
  }
}
