// src/app/components/admin/manage-users/manage-users.ts
import { Component, OnInit } from '@angular/core';
import { UserService } from '../../../services/user/user.service';

@Component({
  selector: 'app-manage-users',
  standalone:false,
  templateUrl: './manage-users.html',
  styleUrls: ['./manage-users.css']
})
export class ManageUsers implements OnInit {
  users: any[] = [];
  loading = false;
  error = '';

  // Form state
  showForm = false;
  isEdit = false;
  formModel: any = {
    userId: 0,
    username: '',
    password: '',
    role: 'User',
    profileImagePath: ''
  };

  constructor(private userService: UserService) {}

  ngOnInit(): void {
    this.loadUsers();
  }

  loadUsers(): void {
    this.loading = true;
    this.userService.getUsers().subscribe({
      next: (data: any[]) => {
        this.users = data || [];
        this.loading = false;
      },
      error: (err: any) => {
        console.error('Failed to load users', err);
        this.error = 'Failed to load users';
        this.loading = false;
      }
    });
  }

  openCreate(): void {
    this.isEdit = false;
    this.formModel = { userId: 0, username: '', password: '', role: 'User', profileImagePath: '' };
    this.showForm = true;
  }

  openEdit(user: any): void {
    this.isEdit = true;
    this.formModel = {
      userId: user.userId,
      username: user.username,
      password: '',
      role: user.role,
      profileImagePath: user.profileImagePath || ''
    };
    this.showForm = true;
  }

  cancelForm(): void {
    this.showForm = false;
    this.isEdit = false;
  }

  save(): void {
    if (!this.formModel.username || (!this.isEdit && !this.formModel.password)) {
      alert('Username and password are required for new users. For edits, password is optional.');
      return;
    }

    if (this.isEdit) {
      const payload: any = {
        userId: this.formModel.userId,
        username: this.formModel.username,
        role: this.formModel.role,
        profileImagePath: this.formModel.profileImagePath
      };
      if (this.formModel.password) payload.password = this.formModel.password;

      this.userService.updateUser(this.formModel.userId, payload).subscribe({
        next: () => {
          alert('User updated');
          this.showForm = false;
          this.loadUsers();
        },
        error: (err: any) => {
          console.error('Update failed', err);
          alert('Update failed');
        }
      });
    } else {
      const payload = {
        username: this.formModel.username,
        password: this.formModel.password,
        role: this.formModel.role,
        profileImagePath: this.formModel.profileImagePath
      };

      this.userService.createUser(payload).subscribe({
        next: () => {
          alert('User created');
          this.showForm = false;
          this.loadUsers();
        },
        error: (err: any) => {
          console.error('Create failed', err);
          alert('Create failed: ' + (err?.error || ''));
        }
      });
    }
  }

  deleteUser(userId: number): void {
    if (!confirm('Delete user? This action cannot be undone.')) return;

    this.userService.deleteUser(userId).subscribe({
      next: () => {
        alert('User deleted');
        this.loadUsers();
      },
      error: (err: any) => {
        console.error('Delete failed', err);
        alert('Delete failed');
      }
    });
  }
}
