// src/app/components/admin/manage-appointments/manage-appointments.ts
import { Component, OnInit } from '@angular/core';
import { AppointmentService } from '../../../services/appointment/appointment.service';

@Component({
  selector: 'app-manage-appointments',
  standalone: false,
  templateUrl: './manage-appointments.html',
  styleUrls: ['./manage-appointments.css']
})
export class ManageAppointments implements OnInit {
  appointments: any[] = [];
  editModel: any = null; // holds appointment being edited

  constructor(private appointmentService: AppointmentService) {}

  ngOnInit(): void {
    this.loadAppointments();
  }

  loadAppointments() {
    this.appointmentService.getAppointments().subscribe({
      next: (data) => {
        console.log('📋 Loaded appointments:', data);
        this.appointments = data;
      },
      error: (err) => console.error('❌ Error loading appointments:', err)
    });
  }

  startEdit(appointment: any) {
    console.log('✏️ Editing appointment:', appointment);
    this.editModel = { ...appointment };

    // Keep only yyyy-MM-dd for <input type="date">
    if (this.editModel.appointmentDate?.includes('T')) {
      this.editModel.appointmentDate = this.editModel.appointmentDate.split('T')[0];
    }
  }

  saveEdit() {
    console.log('💾 Preparing to save edit:', this.editModel);

    // Ensure ISO date (yyyy-MM-ddTHH:mm:ss)
    let isoDate = this.editModel.appointmentDate;
    if (isoDate && !isoDate.includes('T')) {
      isoDate = `${isoDate}T00:00:00`;
    }

    const payload = {
      appointmentId: this.editModel.appointmentId,
      userId: this.editModel.userId,
      doctorId: this.editModel.doctorId,
      appointmentDate: isoDate,
      timeSlot: this.editModel.timeSlot,
      status: this.editModel.status
    };

    console.log('📤 Sending update payload:', payload);

    this.appointmentService.updateAppointment(this.editModel.appointmentId, payload).subscribe({
      next: () => {
        alert('✅ Appointment updated successfully');
        this.editModel = null;
        this.loadAppointments();
      },
      error: (err) => {
        console.error('❌ Update failed:', err);
        alert('Update failed. Please try again.');
      }
    });
  }

  cancelAppointment(id: number) {
    console.log('❌ Cancelling appointment:', id);
    if (confirm('Cancel this appointment?')) {
      this.appointmentService.cancelAppointment(id).subscribe({
        next: () => {
          alert('Appointment cancelled');
          this.loadAppointments();
        },
        error: (err) => console.error('Error cancelling appointment:', err)
      });
    }
  }

  deleteAppointment(id: number) {
    console.log('🗑 Deleting appointment:', id);
    if (confirm('Delete this appointment?')) {
      this.appointmentService.deleteAppointment(id).subscribe({
        next: () => {
          alert('Appointment deleted');
          this.loadAppointments();
        },
        error: (err) => console.error('Error deleting appointment:', err)
      });
    }
  }

  cancelEdit() {
    this.editModel = null;
  }
}
