import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-dashboard',
  standalone: false,
  templateUrl: './admin-dashboard.html',
  styleUrls: ['./admin-dashboard.css']
})
export class AdminDashboard {
  username: string = '';

  constructor(private router: Router) {
    this.username = localStorage.getItem('username') || 'Admin';
  }

  // ✅ Logout clears storage & redirects
  logout() {
    localStorage.clear();
    this.router.navigate(['/login']);
  }

  // ✅ Navigation helpers for clarity
  goToUsers() {
    this.router.navigate(['/admin/users']);
  }

  goToDoctors() {
    this.router.navigate(['/admin/doctors']);
  }

  goToSpecializations() {
    this.router.navigate(['/admin/specializations']);
  }

  goToAppointments() {
    this.router.navigate(['/admin/appointments']);
  }
}
