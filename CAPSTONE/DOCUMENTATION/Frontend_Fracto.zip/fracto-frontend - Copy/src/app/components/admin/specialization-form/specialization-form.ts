import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { SpecializationService } from '../../../services/specialization/specialization.service';

@Component({
  selector: 'app-specialization-form',
  standalone:false,
  templateUrl: './specialization-form.html',
  styleUrls: ['./specialization-form.css']
})
export class SpecializationForm implements OnInit {
  @Input() specialization: any = null;
  @Output() saved = new EventEmitter<void>();

  model: { specializationName: string } = { specializationName: '' };
  saving = false;

  constructor(private specService: SpecializationService) {}

  ngOnInit(): void {
    if (this.specialization) {
      this.model = { ...this.specialization };
    }
  }

  save(): void {
    this.saving = true;

    if (this.specialization && this.specialization.specializationId) {
      // Update existing
      this.specService.updateSpecialization(this.specialization.specializationId, this.model).subscribe({
        next: () => {
          this.saving = false;
          this.saved.emit();
        },
        error: (err: any) => {
          this.saving = false;
          console.error(err);
          alert('Update failed');
        }
      });
    } else {
      // Create new
      this.specService.createSpecialization(this.model).subscribe({
        next: () => {
          this.saving = false;
          // reset model for convenience
          this.model = { specializationName: '' };
          this.saved.emit();
        },
        error: (err: any) => {
          this.saving = false;
          console.error(err);
          alert('Create failed');
        }
      });
    }
  }

  cancel(): void {
    this.saved.emit();
  }
}
