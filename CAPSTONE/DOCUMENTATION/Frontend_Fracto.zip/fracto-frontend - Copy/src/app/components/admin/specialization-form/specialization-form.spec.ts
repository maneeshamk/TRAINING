import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SpecializationForm } from './specialization-form';

describe('SpecializationForm', () => {
  let component: SpecializationForm;
  let fixture: ComponentFixture<SpecializationForm>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [SpecializationForm]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SpecializationForm);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
