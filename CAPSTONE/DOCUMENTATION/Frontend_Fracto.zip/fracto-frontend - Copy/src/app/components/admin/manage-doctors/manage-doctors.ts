import { Component, OnInit } from '@angular/core';
import { DoctorService } from '../../../services/doctor/doctor.service';
import { SpecializationService } from '../../../services/specialization/specialization.service';

@Component({
  selector: 'app-manage-doctors',
  standalone:false,
  templateUrl: './manage-doctors.html',
  styleUrls: ['./manage-doctors.css']
})
export class ManageDoctors implements OnInit {
  doctors: any[] = [];
  specializations: any[] = [];
  loading = false;
  showForm = false;
  editDoctor: any = null;

  constructor(
    private doctorService: DoctorService,
    private specService: SpecializationService
  ) {}

  ngOnInit(): void {
    this.loadAll();
  }

  loadAll() {
    this.loadDoctors();
    this.loadSpecializations();
  }

  loadDoctors() {
    this.loading = true;
    this.doctorService.getDoctors().subscribe({
      next: (data: any[]) => { this.doctors = data || []; this.loading = false; },
      error: (err: any) => { console.error(err); this.loading = false; }
    });
  }

  loadSpecializations() {
    this.specService.getSpecializations().subscribe({
      next: (data: any[]) => this.specializations = data || [],
      error: (err: any) => console.error(err)
    });
  }

  addDoctor() {
    this.editDoctor = null;
    this.showForm = true;
  }

  edit(d: any) {
    this.editDoctor = { ...d };
    this.showForm = true;
  }

  onSaved() {
    this.showForm = false;
    this.loadDoctors();
  }

  deleteDoctor(id: number) {
    if (!confirm('Delete doctor?')) return;
    this.doctorService.deleteDoctor(id).subscribe({
      next: () => this.loadDoctors(),
      error: (err: any) => { console.error(err); alert('Delete failed'); }
    });
  }
}
