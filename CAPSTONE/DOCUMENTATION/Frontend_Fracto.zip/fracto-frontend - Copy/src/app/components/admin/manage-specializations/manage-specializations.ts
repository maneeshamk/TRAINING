import { Component, OnInit } from '@angular/core';
import { SpecializationService } from '../../../services/specialization/specialization.service';

@Component({
  selector: 'app-manage-specializations',
  standalone:false,
  templateUrl: './manage-specializations.html',
  styleUrls: ['./manage-specializations.css']
})
export class ManageSpecializations implements OnInit {
  specs: any[] = [];
  loading = false;
  newName = '';
  editSpec: any = null;
  error = '';

  constructor(private specService: SpecializationService) {}

  ngOnInit(): void {
    this.load();
  }

  load() {
    this.loading = true;
    this.specService.getSpecializations().subscribe({
      next: (data: any[]) => { this.specs = data || []; this.loading = false; },
      error: (err: any) => { console.error(err); this.loading = false; }
    });
  }

  create() {
    if (!this.newName.trim()) return;
    this.specService.createSpecialization({ specializationName: this.newName.trim() }).subscribe({
      next: () => { this.newName = ''; this.load(); },
      error: (err: any) => { console.error(err); alert('Create failed'); }
    });
  }

  startEdit(s: any) {
    this.editSpec = { ...s };
  }

  saveEdit() {
    if (!this.editSpec) return;
    this.specService.updateSpecialization(this.editSpec.specializationId, this.editSpec).subscribe({
      next: () => { this.editSpec = null; this.load(); },
      error: (err: any) => { console.error(err); alert('Update failed'); }
    });
  }

  cancelEdit() {
    this.editSpec = null;
  }

  deleteSpec(id: number) {
    if (!confirm('Delete specialization?')) return;
    this.specService.deleteSpecialization(id).subscribe({
      next: () => this.load(),
      error: (err: any) => { console.error(err); alert('Delete failed'); }
    });
  }
}
