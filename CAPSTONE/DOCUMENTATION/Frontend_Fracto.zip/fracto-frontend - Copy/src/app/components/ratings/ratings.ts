// src/app/components/ratings/ratings.ts
import { Component, OnInit } from '@angular/core';
import { RatingService } from '../../services/ratings/ratings.service';
import { DoctorService } from '../../services/doctor/doctor.service';

@Component({
  selector: 'app-ratings',
  standalone:false,
  templateUrl: './ratings.html',
  styleUrls: ['./ratings.css']
})
export class Ratings implements OnInit {
  doctors: any[] = [];
  ratings: any[] = [];

  // form model
  selectedDoctor: number = 0;
  ratingValue: number = 5;
  comment: string = '';

  loadingDoctors = false;
  submitting = false;
  errorMessage = '';

  constructor(
    private ratingsService: RatingService,
    private doctorService: DoctorService
  ) {}

  ngOnInit() {
    this.loadDoctors();
  }

  loadDoctors() {
    this.loadingDoctors = true;
    this.doctorService.getDoctors().subscribe({
      next: (data) => {
        this.doctors = data || [];
        this.loadingDoctors = false;
      },
      error: (err) => {
        console.error('Error loading doctors:', err);
        this.errorMessage = 'Unable to load doctors';
        this.loadingDoctors = false;
      }
    });
  }

  // load ratings for selected doctor
  loadRatingsForSelectedDoctor() {
    if (!this.selectedDoctor) {
      this.ratings = [];
      return;
    }
    this.ratingsService.getRatingsByDoctor(this.selectedDoctor).subscribe({
      next: (data) => this.ratings = data || [],
      error: (err) => {
        console.error('Error loading ratings:', err);
        this.errorMessage = 'Unable to load ratings';
      }
    });
  }

  submitRating() {
    this.errorMessage = '';
    if (!this.selectedDoctor) {
      this.errorMessage = 'Select a doctor first';
      return;
    }
    if (!this.ratingValue || this.ratingValue < 1 || this.ratingValue > 5) {
      this.errorMessage = 'Rating must be between 1 and 5';
      return;
    }

    const payload: any = {
      doctorId: Number(this.selectedDoctor),
      ratingValue: Number(this.ratingValue)
    };
    // include comment if backend supports it (safe to include)
    if (this.comment && this.comment.trim()) payload.comment = this.comment.trim();

    this.submitting = true;
    this.ratingsService.submitRating(payload).subscribe({
      next: (res) => {
        alert('Rating submitted successfully');
        // clear form and reload ratings
        this.comment = '';
        this.ratingValue = 5;
        this.submitting = false;
        this.loadRatingsForSelectedDoctor();
      },
      error: (err) => {
        console.error('Submit rating error:', err);
        this.submitting = false;

        // Friendly errors
        if (err.status === 401) this.errorMessage = 'Not authenticated. Please login.';
        else if (err.status === 403) this.errorMessage = 'Not authorized to rate. Check your role.';
        else this.errorMessage = err.error && typeof err.error === 'string' ? err.error : 'Failed to submit rating.';
      }
    });
  }
}
