import { Component, OnInit } from '@angular/core';
import { UserService } from '../../../services/user/user.service';

@Component({
  selector: 'app-upload-avatar',
  standalone: false,
  templateUrl: './upload-avatar.html',
  styleUrls: ['./upload-avatar.css']
})
export class UploadAvatar implements OnInit {
  selectedFile: File | null = null;
  previewUrl: string | null = null;
  uploading = false;
  userId: number = 0;
  currentAvatarUrl: string | null = null;

  constructor(private userService: UserService) {}

  ngOnInit(): void {
    // Read logged-in user id from localStorage (set during login)
    const idStr = localStorage.getItem('userId');
    this.userId = idStr ? Number(idStr) : 0;

    // If we already stored avatar URL in localStorage, show it
    this.currentAvatarUrl = localStorage.getItem('profileImageUrl') || null;

    // Otherwise try to fetch user data from backend and get profileImagePath
    if (!this.currentAvatarUrl && this.userId) {
      this.userService.getUser(this.userId).subscribe({
        next: (u) => {
          if (u?.profileImagePath) {
            // build absolute URL to backend-hosted file
            this.currentAvatarUrl = `${window.location.protocol}//${window.location.host}/${u.profileImagePath}`;
            // cache it
            localStorage.setItem('profileImageUrl', this.currentAvatarUrl);
          }
        },
        error: (err) => {
          // ignore — not critical
          console.warn('Could not fetch user profile', err);
        }
      });
    }
  }

  onFileSelected(evt: Event) {
    const input = evt.target as HTMLInputElement;
    if (!input.files || input.files.length === 0) return;
    const file = input.files[0];

    // optional: check file type/size client-side
    const allowed = ['image/png', 'image/jpeg', 'image/jpg', 'image/gif'];
    if (!allowed.includes(file.type)) {
      alert('Please select a PNG/JPG/GIF image.');
      return;
    }
    if (file.size > 2 * 1024 * 1024) {
      alert('File too large. Max 2 MB allowed.');
      return;
    }

    this.selectedFile = file;

    // preview
    const reader = new FileReader();
    reader.onload = (e: ProgressEvent<FileReader>) => {
      this.previewUrl = e.target?.result as string;
    };
    reader.readAsDataURL(file);
  }

  upload() {
    if (!this.selectedFile) {
      alert('Please select a file first.');
      return;
    }
    if (!this.userId) {
      alert('User not identified. Please login again.');
      return;
    }

    this.uploading = true;
    this.userService.uploadAvatar(this.userId, this.selectedFile).subscribe({
      next: (res) => {
        this.uploading = false;
        // expecting response.url (absolute) and/or relativePath
        const url = res?.url ?? (res?.relativePath ? `${window.location.protocol}//${window.location.host}/${res.relativePath}` : null);
        if (url) {
          this.currentAvatarUrl = url;
          localStorage.setItem('profileImageUrl', url);
        }
        this.previewUrl = null;
        this.selectedFile = null;
        alert('Upload successful');
      },
      error: (err) => {
        this.uploading = false;
        console.error('Upload failed', err);
        alert('Upload failed. Check console for details.');
      }
    });
  }

  removePreview() {
    this.previewUrl = null;
    this.selectedFile = null;
  }
}
