import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UploadAvatar } from './upload-avatar';

describe('UploadAvatar', () => {
  let component: UploadAvatar;
  let fixture: ComponentFixture<UploadAvatar>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [UploadAvatar]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UploadAvatar);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
