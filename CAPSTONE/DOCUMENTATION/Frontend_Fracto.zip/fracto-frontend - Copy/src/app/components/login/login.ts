import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-login',
  standalone: false,
  templateUrl: './login.html',
  styleUrls: ['./login.css']
})
export class Login {
  username: string = '';
  password: string = '';
  errorMessage: string = '';

  private apiUrl = 'http://localhost:5005/api/Auth/login'; // ✅ Backend login API

  constructor(private http: HttpClient, private router: Router) {}

  onSubmit() {
    const loginData = {
      Username: this.username, // match backend DTO
      Password: this.password
    };

    this.http.post<any>(this.apiUrl, loginData).subscribe({
      next: (response) => {
        console.log('✅ Login success. Full response:', response);

        // ✅ Save JWT token
        localStorage.setItem('token', response.token);

        // ✅ Save role, username, and userId
        const roleFromBackend = response.user.role;
        const role = roleFromBackend ? roleFromBackend.toLowerCase() : 'user';

        console.log('🔎 Role received from backend:', roleFromBackend);
        console.log('💾 Saving role as:', role);

        localStorage.setItem('role', role);
        localStorage.setItem('username', response.user.username);
        localStorage.setItem('userId', response.user.userId.toString()); // 👈 save userId

        // ✅ Redirect by role
        if (role === 'admin') {
          this.router.navigate(['/admin']);   // ✅ fixed
        } else {
          this.router.navigate(['/user-dashboard']);
        }
      },
      error: (err) => {
        console.error('❌ Login error:', err);

        this.errorMessage =
          err.error && typeof err.error === 'string'
            ? err.error
            : err.error?.message || 'Login failed. Please check your credentials.';
      }
    });
  }
}
