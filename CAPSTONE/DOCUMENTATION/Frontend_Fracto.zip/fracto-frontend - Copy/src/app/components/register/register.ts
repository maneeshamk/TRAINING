import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Auth } from '../../services/auth/auth.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.html',
  standalone: false,
  styleUrls: ['./register.css']
})
export class Register {
  username: string = '';
  password: string = '';
  role: string = 'User'; // default role
  errorMessage: string = '';
  successMessage: string = '';

  constructor(private auth: Auth, private router: Router) {}

  onRegister() {
    const payload = {
      Username: this.username,
      Password: this.password,
      Role: this.role,
      ProfileImagePath: 'string'   // ✅ always send default value
    };

    this.auth.register(payload).subscribe({
      next: (res: any) => {
        console.log('✅ Registration successful:', res);
        this.successMessage = res.message || 'Registration successful! Redirecting to login...';
        this.errorMessage = '';
        setTimeout(() => {
          this.router.navigate(['/login']);
        }, 1500);
      },
      error: (err) => {
        console.error('❌ Registration failed:', err);
        this.errorMessage = err.error?.message || '❌ Registration failed!';
        this.successMessage = '';
      }
    });
  }
}
