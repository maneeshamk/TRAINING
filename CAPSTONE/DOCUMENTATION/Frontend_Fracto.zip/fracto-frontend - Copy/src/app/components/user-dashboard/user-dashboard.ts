import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-dashboard',
  standalone: false,
  templateUrl: './user-dashboard.html',
  styleUrls: ['./user-dashboard.css']
})
export class UserDashboard implements OnInit {
  username: string = '';
  profileImageUrl: string | null = null;

  constructor(private router: Router) {}

  ngOnInit(): void {
    this.username = localStorage.getItem('username') || 'User';
    this.profileImageUrl = localStorage.getItem('profileImageUrl') || null;
  }

  logout() {
    localStorage.clear();
    this.router.navigate(['/login']);
  }
}
