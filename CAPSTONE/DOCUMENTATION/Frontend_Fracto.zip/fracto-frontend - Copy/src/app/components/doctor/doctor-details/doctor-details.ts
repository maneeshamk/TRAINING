import { Component } from '@angular/core';

@Component({
  selector: 'app-doctor-details',
  standalone: false,
  templateUrl: './doctor-details.html',
  styleUrl: './doctor-details.css'
})
export class DoctorDetails {

}
