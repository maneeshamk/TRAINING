import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-doctors-list',
  standalone:false,
  templateUrl: './doctors-list.html',
  styleUrls: ['./doctors-list.css']
})
export class DoctorsList implements OnInit {
  doctors: any[] = [];
  apiUrl = 'http://localhost:5005/api/Doctors';

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.loadDoctors();
  }

  loadDoctors() {
    this.http.get<any[]>(this.apiUrl).subscribe({
      next: (res) => {
        this.doctors = res;
      },
      error: (err) => {
        console.error('❌ Error loading doctors:', err);
      }
    });
  }
}
