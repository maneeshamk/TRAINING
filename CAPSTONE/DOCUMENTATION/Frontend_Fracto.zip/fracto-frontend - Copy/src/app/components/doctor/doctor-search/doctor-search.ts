import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DoctorService } from '../../../services/doctor/doctor.service';
import { SpecializationService } from '../../../services/specialization/specialization.service';

@Component({
  selector: 'app-doctor-search',
  standalone: false,
  templateUrl: './doctor-search.html',
  styleUrls: ['./doctor-search.css']
})
export class DoctorSearch implements OnInit {
  doctors: any[] = [];
  filtered: any[] = [];
  specializations: any[] = [];
  cities: string[] = [];

  selectedCity: string = '';
  selectedSpecialization: number = 0;
  selectedDate: string = '';
  minRating: number = 0;

  loading = false;
  error = '';

  constructor(
    private doctorService: DoctorService,
    private specializationService: SpecializationService,
    private router: Router
  ) {}

  ngOnInit() {
    this.loadSpecializations();
    this.loadDoctors();
  }

  loadSpecializations() {
    this.specializationService.getSpecializations().subscribe({
      next: (data) => (this.specializations = data || []),
      error: (err) => {
        console.error(err);
        this.error = 'Failed to load specializations';
      }
    });
  }

  loadDoctors() {
    this.loading = true;
    this.doctorService.getDoctors().subscribe({
      next: (data) => {
        this.doctors = data || [];
        const citySet = new Set<string>();
        this.doctors.forEach((d) => {
          if (d.city) citySet.add(d.city);
        });
        this.cities = Array.from(citySet).sort();
        this.applyFilters();
        this.loading = false;
      },
      error: (err) => {
        console.error(err);
        this.error = 'Failed to load doctors';
        this.loading = false;
      }
    });
  }

  applyFilters() {
    this.filtered = this.doctors.filter((d) => {
      if (this.selectedCity && d.city?.toLowerCase() !== this.selectedCity.toLowerCase()) return false;
      if (this.selectedSpecialization && d.specializationId !== Number(this.selectedSpecialization)) return false;
      if (this.minRating && (d.rating ?? 0) < Number(this.minRating)) return false;
      return true;
    });
  }

  searchDoctors() {
    this.applyFilters();
  }

  clearFilters() {
    this.selectedCity = '';
    this.selectedSpecialization = 0;
    this.selectedDate = '';
    this.minRating = 0;
    this.applyFilters();
  }

  book(doctor: any) {
    this.router.navigate(['/appointment-book'], {
      queryParams: { doctorId: doctor.doctorId }
    });
  }
}
