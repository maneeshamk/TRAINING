// auth.guard.ts - UPDATED
import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, Router, RouterStateSnapshot } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  constructor(private router: Router) {}

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    const token = localStorage.getItem('token');
    const role = localStorage.getItem('role');

    console.log('🔑 AuthGuard check for route:', route.routeConfig?.path);
    console.log('   token =', token ? 'Present' : 'Missing');
    console.log('   role =', role);

    if (!token) {
      console.warn('🚫 No token → redirecting to login');
      this.router.navigate(['/login']);
      return false;
    }

    // Check if route requires specific role
    const requiredRole = route.data['role'] as string;
    console.log('   requiredRole =', requiredRole || 'None');

    // If route doesn't require specific role, allow access
    if (!requiredRole) {
      console.log('✅ No role required → access granted');
      return true;
    }

    // Check if user has the required role
    if (role !== requiredRole.toLowerCase()) {
      console.warn(`🚫 Role mismatch → expected ${requiredRole}, but user is ${role}`);
      this.router.navigate(['/login']);
      return false;
    }

    console.log('✅ Role matches → access granted');
    return true;
  }
}