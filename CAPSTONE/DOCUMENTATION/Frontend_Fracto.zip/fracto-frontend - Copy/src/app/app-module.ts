import { NgModule, provideBrowserGlobalErrorListeners } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms'; 
import { HttpClientModule } from '@angular/common/http'; 

import { AppRoutingModule } from './app-routing.module';
import { App } from './app';
import { Login } from './components/login/login';
import { Register } from './components/register/register';
import { DoctorsList } from './components/doctor/doctors-list/doctors-list';
import { DoctorDetails } from './components/doctor/doctor-details/doctor-details';
import { AppointmentsList } from './components/appointment/appointments-list/appointments-list';
import { AppointmentBook } from './components/appointment/appointment-book/appointment-book';
import { Ratings } from './components/ratings/ratings';
import { AdminDashboard } from './components/admin/admin-dashboard/admin-dashboard';
import { UserDashboard } from './components/user-dashboard/user-dashboard';
import { DoctorSearch } from './components/doctor/doctor-search/doctor-search';
import { MyAppointments } from './components/appointment/my-appointments/my-appointments';
import { Home } from './components/home/home';
import { ManageUsers } from './components/admin/manage-users/manage-users';
import { ManageDoctors } from './components/admin/manage-doctors/manage-doctors';
import { ManageSpecializations } from './components/admin/manage-specializations/manage-specializations';
import { ManageAppointments } from './components/admin/manage-appointments/manage-appointments';
import { DoctorForm } from './components/admin/doctor-form/doctor-form';
import { SpecializationForm } from './components/admin/specialization-form/specialization-form';
import { UploadAvatar } from './components/profile/upload-avatar/upload-avatar';


@NgModule({
  declarations: [
    App,
    Login,
    Register,
    DoctorsList,
    DoctorDetails,
    AppointmentsList,
    AppointmentBook,
    Ratings,
    AdminDashboard,
    UserDashboard,
    DoctorSearch,
    MyAppointments,
    Home,
    ManageUsers,
    ManageDoctors,
    ManageSpecializations,
    ManageAppointments,
    DoctorForm,
    SpecializationForm,
    UploadAvatar
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,         
    HttpClientModule     
  ],
  providers: [
    provideBrowserGlobalErrorListeners()
  ],
  bootstrap: [App]
})
export class AppModule { }
