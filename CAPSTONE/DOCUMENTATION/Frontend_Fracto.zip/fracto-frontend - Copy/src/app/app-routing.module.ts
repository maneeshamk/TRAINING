import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Home } from './components/home/home';
import { Login } from './components/login/login';
import { Register } from './components/register/register';
import { AdminDashboard } from './components/admin/admin-dashboard/admin-dashboard';
import { UserDashboard } from './components/user-dashboard/user-dashboard';
import { DoctorsList } from './components/doctor/doctors-list/doctors-list';
import { AppointmentBook } from './components/appointment/appointment-book/appointment-book';
import { AppointmentsList } from './components/appointment/appointments-list/appointments-list';
import { Ratings } from './components/ratings/ratings';
import { AuthGuard } from './guards/auth.guard';

// ✅ Import admin management components
import { ManageUsers } from './components/admin/manage-users/manage-users';
import { ManageDoctors } from './components/admin/manage-doctors/manage-doctors';
import { ManageSpecializations } from './components/admin/manage-specializations/manage-specializations';
import { ManageAppointments } from './components/admin/manage-appointments/manage-appointments';
import { DoctorSearch } from './components/doctor/doctor-search/doctor-search';
const routes: Routes = [
  // ✅ Root -> Home (landing page with FRACTO tagline)
  { path: '', component: Home },

  // Public
  { path: 'login', component: Login },
  { path: 'register', component: Register },

  // ✅ User area (guarded, role: user)
  {
    path: 'user-dashboard',
    component: UserDashboard,
    canActivate: [AuthGuard],
    data: { role: 'user' }
  },
  {
    path: 'doctors',
    component: DoctorsList,
    canActivate: [AuthGuard],
    data: { role: 'user' }
  },
  {
  path: 'doctor-search',              
  component: DoctorSearch,
  canActivate: [AuthGuard],
  data: { role: 'user' }
},
  {
    path: 'appointment-book',
    component: AppointmentBook,
    canActivate: [AuthGuard],
    data: { role: 'user' }
  },
  {
    path: 'appointments-list',
    component: AppointmentsList,
    canActivate: [AuthGuard],
    data: { role: 'user' }
  },
  {
    path: 'ratings',
    component: Ratings,
    canActivate: [AuthGuard],
    data: { role: 'user' }
  },

  // ✅ Admin area (parent with children)
  {
    path: 'admin',
    canActivate: [AuthGuard],
    data: { role: 'admin' },
    children: [
      { path: '', component: AdminDashboard },           // /admin
      { path: 'users', component: ManageUsers },         // /admin/users
      { path: 'doctors', component: ManageDoctors },     // /admin/doctors
      { path: 'specializations', component: ManageSpecializations }, // /admin/specializations
      { path: 'appointments', component: ManageAppointments }           // /admin/appointments
    ]
  },

  // Wildcard (unknown paths) → back to Home
  { path: '**', redirectTo: '' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
