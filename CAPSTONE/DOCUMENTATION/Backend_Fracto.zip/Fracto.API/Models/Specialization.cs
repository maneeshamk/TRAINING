// Models/Specialization.cs
namespace Fracto.API.Models
{
    public class Specialization
    {
        public int SpecializationId { get; set; }
        public string SpecializationName { get; set; }
    }
}