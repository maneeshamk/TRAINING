document.getElementById("btnClick").addEventListener("click", showMessage);

function showMessage() {
    alert("Hello from JavaScript!");
}
