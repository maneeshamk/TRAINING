# Setup & Execution

1. Prerequisites: 
Install .NET 6 SDK or later
Install Visual Studio Code or Visual Studio 2022+
Install C# Dev Kit extension in VS Code

2. Run the Application:
Open a terminal in the MiddlewareDemo folder and run:
dotnet restore
dotnet watch run

You will see like this in your browser: http://localhost:5053

# Note: The port (5053) may vary. Use the exact ones shown in your terminal.

3. Open in Browser:
Middleware default route →
https://localhost:<port>/
Example: http://localhost:5053/

Static file (HTML, CSS, JS) →
https://localhost:<port>/index.html
Example: http://localhost:5053/index.html

Error page →
https://localhost:<port>/error
Example: http://localhost:5053/error


# Features Implemented
1. Middleware : Logs request method + path and response status using Console.WriteLine.
Custom error handler → returns a simple error page.

2. Static Files : Configured wwwroot folder with:
index.html (UI page)
style.css (styling)
script.js (JavaScript)

3. Security : Enforces HTTPS with app.UseHsts().
Adds Content Security Policy (CSP) headers to prevent XSS:
context.Response.Headers.Add("Content-Security-Policy",
    "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self' wss:;");

4. Browser Interaction : Page loads from static files. Button click triggers JavaScript alert (wired via external script.js, CSP-compliant).

# How to Test
Open /index.html in the browser.
Verify: Page styles load (style.css).
Clicking Click Me button shows alert popup (script.js).
Watch the terminal → request & response logs appear.
Open /error → see custom error page.
Inspect browser Dev Tools → Network tab → confirm CSP headers are present.