var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

// Middleware for logging
app.Use(async (context, next) =>
{
    Console.WriteLine($"Request: {context.Request.Method} {context.Request.Path}");
    await next.Invoke();
    Console.WriteLine($"Response: {context.Response.StatusCode}");
});

// Error handling
app.UseExceptionHandler("/error");

// Enforce HTTPS
app.UseHsts();

// CSP security headers
app.Use(async (context, next) =>
{
    context.Response.Headers.Add("Content-Security-Policy",
        "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self' wss:;");
    await next.Invoke();
});

// Serve static files
app.UseStaticFiles();

// Default route
app.MapGet("/", () => "Hello from MiddlewareDemo!");

// Error route
app.MapGet("/error", () => Results.Content("<h1>Something went wrong!</h1>", "text/html"));

app.Run();