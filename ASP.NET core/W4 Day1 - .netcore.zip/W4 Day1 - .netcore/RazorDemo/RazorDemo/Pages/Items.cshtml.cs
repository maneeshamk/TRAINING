using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RazorDemo.Pages
{
    public class ItemsModel : PageModel
    {
        public static List<string> Items = new() { "Book", "Pen", "Laptop" };
        public List<string> ItemsCopy { get; set; }

        public void OnGet()
        {
            ItemsCopy = new List<string>(Items);
        }
    }
}
