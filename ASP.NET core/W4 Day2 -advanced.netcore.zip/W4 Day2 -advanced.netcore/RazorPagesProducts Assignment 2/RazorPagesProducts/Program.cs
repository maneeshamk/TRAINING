using RazorPagesProducts.Models;

namespace RazorPagesProducts
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);
            var seedStore = new ProductStore();
            seedStore.Add(new Product
            {
                Name = "Ultrabook Laptop",
                Description = "Slim 14-inch laptop with long battery life.",
                Categories = new List<Category>
                {
                    new Category { Name = "Electronics" },
                    new Category { Name = "Computers" }
                }
            });
            seedStore.Add(new Product
            {
                Name = "Noise-Cancelling Headphones",
                Description = "Over-ear ANC with Bluetooth.",
                Categories = new List<Category>
                {
                    new Category { Name = "Audio" },
                    new Category { Name = "Accessories" }
                }
            });

            builder.Services.AddSingleton<ProductStore>(seedStore);
            builder.Services.AddRazorPages().AddRazorPagesOptions(options =>
            {
                // Conventional routes (friendly URLs)
                options.Conventions.AddPageRoute("/Products/Details", "Products/{id:int}");
            });

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (!app.Environment.IsDevelopment())
            {
                app.UseExceptionHandler("/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();

            app.UseAuthorization();

            app.MapRazorPages();

            app.Run();
        }
    }
}
