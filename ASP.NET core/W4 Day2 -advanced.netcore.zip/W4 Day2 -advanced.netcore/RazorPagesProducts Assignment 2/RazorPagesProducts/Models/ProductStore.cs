﻿using System.Collections.Concurrent;

namespace RazorPagesProducts.Models
{
    public class ProductStore
    {
        private readonly ConcurrentDictionary<int, Product> _products = new();
        private int _nextId = 0;

        public IEnumerable<Product> All => _products.Values.OrderBy(p => p.ProductID);

        public Product Add(Product p)
        {
            var id = Interlocked.Increment(ref _nextId);
            p.ProductID = id;
            _products[id] = p;
            return p;
        }

        public Product? Get(int id) => _products.TryGetValue(id, out var p) ? p : null;
    }
}
