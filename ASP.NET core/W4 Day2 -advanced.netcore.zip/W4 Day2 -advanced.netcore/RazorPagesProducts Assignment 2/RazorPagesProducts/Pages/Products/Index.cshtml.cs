using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using RazorPagesProducts.Models;

namespace RazorPagesProducts.Pages.Products
{
    public class IndexModel : PageModel
    {
        private readonly ProductStore _store;

        public IndexModel(ProductStore store)
        {
            _store = store;
            NewProduct = new Product();
            Products = new List<Product>();
        }

        [BindProperty]
        public Product NewProduct { get; set; } = new();

        public List<Product> Products { get; set; } = new();

        public void OnGet()
        {
            Products = _store.All.ToList();
            Console.WriteLine($"OnGet called. Products.Count = {Products.Count}");
            // Render two category fields by default
            if (NewProduct.Categories.Count == 0)
            {
                NewProduct.Categories.Add(new Category());
                NewProduct.Categories.Add(new Category());
            }
        }

        public IActionResult OnPost()
        {
            // Remove empty category names
            NewProduct.Categories ??= new List<Category>();


            NewProduct.Categories = NewProduct.Categories
                .Where(c => !string.IsNullOrWhiteSpace(c.Name))
                .ToList();

            if (!ModelState.IsValid)
            {
                Products = _store.All.ToList();
                return Page();
            }

            _store.Add(NewProduct);
            return RedirectToPage("./Index"); // PRG pattern
        }
    }
}
