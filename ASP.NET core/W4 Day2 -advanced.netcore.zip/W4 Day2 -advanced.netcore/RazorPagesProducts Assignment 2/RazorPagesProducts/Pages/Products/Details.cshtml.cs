using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using RazorPagesProducts.Models;

namespace RazorPagesProducts.Pages.Products
{
    public class DetailsModel : PageModel
    {
        private readonly ProductStore _store;
        public Product? Product { get; set; }

        public DetailsModel(ProductStore store)
        {
            _store = store;
        }

        public IActionResult OnGet(int id)
        {
            Product = _store.Get(id);
            if (Product == null) return NotFound();
            return Page();
        }
    }
}
