﻿using System.Collections.Concurrent;

namespace MvcPeople.Models
{
    public class PeopleStore
    {
        private readonly ConcurrentDictionary<int, Person> _people = new();
        private int _nextId = 0;

        public IEnumerable<Person> All => _people.Values;

        public Person Add(Person p)
        {
            var id = Interlocked.Increment(ref _nextId);
            p.Id = id;
            _people[id] = p;
            return p;
        }

        public Person? Get(int id) => _people.TryGetValue(id, out var p) ? p : null;
    }
}
