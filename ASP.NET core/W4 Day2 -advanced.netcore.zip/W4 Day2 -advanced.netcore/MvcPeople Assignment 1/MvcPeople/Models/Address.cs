﻿using System.ComponentModel.DataAnnotations;

namespace MvcPeople.Models
{
    public class Address
    {
        [Required]
        public string Street { get; set; } = string.Empty;

        [Required]
        public string City { get; set; } = string.Empty;

        [Required, Display(Name = "Zip Code")]
        public string ZipCode { get; set; } = string.Empty;
    }
}
