﻿using Microsoft.AspNetCore.Mvc;
using MvcPeople.Models;

namespace MvcPeople.Controllers
{
    public class PeopleController : Controller
    {
        private readonly PeopleStore _store;
        public PeopleController(PeopleStore store) => _store = store;

        public IActionResult Index()
        {
            return View(_store.All);
        }

        public IActionResult Create()
        {
            return View(new Person());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Person person)
        {
            if (!ModelState.IsValid)
            {
                return View(person);
            }

            var saved = _store.Add(person);
            return RedirectToAction(nameof(Details), new { id = saved.Id });
        }
        public IActionResult Details(int id)
        {
            var person = _store.Get(id);
            if (person == null) return NotFound();

            return View(person);
        }
    }
}
