﻿using Microsoft.AspNetCore.Razor.TagHelpers;

namespace CustomerFeedbackPortal.TagHelpers
{
    [HtmlTargetElement("star-rating")]
    public class StarRatingTagHelper : TagHelper
    {
        public int Rating { get; set; }

        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            output.TagName = "div";
            output.TagMode = TagMode.StartTagAndEndTag;

            for (int i = 1; i <= 5; i++)
            {
                string star = i <= Rating ? "★" : "☆";
                output.Content.AppendHtml($"<span style='color:gold; font-size:20px'>{star}</span>");
            }
        }
    }
}
