using Microsoft.AspNetCore.Authentication.Cookies;
using OnlineBookStore.Data;
using OnlineBookStore.Filters;
using OnlineBookStore.Models;
using OnlineBookStore.Validation;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddRazorPages(options =>
{
    // You can add page conventions here if needed
}).AddRazorPagesOptions(options => {});

builder.Services.AddControllersWithViews(options =>
{
    // Global filters
    options.Filters.Add<LogExceptionFilter>();
});

builder.Services.AddSession(options =>
{
    options.Cookie.Name = ".OnlineBookStore.Session";
    options.IdleTimeout = TimeSpan.FromMinutes(30);
    options.Cookie.HttpOnly = true;
});

builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/Account/Login";
        options.LogoutPath = "/Account/Logout";
        options.AccessDeniedPath = "/Account/Login";
    });

// Repositories (in-memory)
builder.Services.AddSingleton<IBookRepository, BookRepository>();
builder.Services.AddSingleton<IOrderRepository, OrderRepository>();
builder.Services.AddSingleton<IUserRepository, UserRepository>();

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseSession();
app.UseAuthentication();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Books}/{action=Index}/{id?}");

app.MapRazorPages();

// Seed initial data
var books = app.Services.GetRequiredService<IBookRepository>();
DataSeeder.Seed(books);

app.Run();

namespace OnlineBookStore
{
    // placeholder program namespace to satisfy top-level statements if needed
}
