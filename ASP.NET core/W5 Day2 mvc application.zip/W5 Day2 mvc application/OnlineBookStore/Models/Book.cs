using System.ComponentModel.DataAnnotations;
using OnlineBookStore.Validation;

namespace OnlineBookStore.Models
{
    public class Book
    {
        public int Id { get; set; }

        [Required, StringLength(200)]
        public string Title { get; set; } = string.Empty;

        [Required, StringLength(200)]
        public string Author { get; set; } = string.Empty;

        [Required, Isbn]
        public string ISBN { get; set; } = string.Empty;

        [PriceRange(0.01, 10000)]
        public decimal Price { get; set; }
    }
}
