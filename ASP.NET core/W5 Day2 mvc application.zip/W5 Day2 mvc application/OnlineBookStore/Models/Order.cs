using System.ComponentModel.DataAnnotations;

namespace OnlineBookStore.Models
{
    public class Order
    {
        public int Id { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        [Required, StringLength(200)]
        public string CustomerEmail { get; set; } = string.Empty;

        public List<CartItem> Items { get; set; } = new();
        public decimal Total => Items.Sum(i => i.Total);
    }
}
