using System.ComponentModel.DataAnnotations;

namespace OnlineBookStore.Models
{
    public class User
    {
        public int Id { get; set; }

        [Required, StringLength(100)]
        public string Username { get; set; } = string.Empty;

        [Required, StringLength(100)]
        public string Password { get; set; } = string.Empty; // For demo only (plain-text). Do NOT use in production.

        public string Role { get; set; } = "User"; // "Admin" or "User"
    }
}
