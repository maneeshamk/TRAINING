using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using OnlineBookStore.Data;
using OnlineBookStore.Models;

namespace OnlineBookStore.Pages.Cart
{
    public class IndexModel : PageModel
    {
        private readonly IBookRepository _books;
        public IndexModel(IBookRepository books) => _books = books;

        public List<CartItem> Items { get; set; } = new();
        public decimal Total => Items.Sum(i => i.Total);

        public void OnGet()
        {
            Items = HttpContext.Session.GetObjectFromJson<List<CartItem>>("cart") ?? new List<CartItem>();
        }

        public IActionResult OnPostAdd(int id)
        {
            var cart = HttpContext.Session.GetObjectFromJson<List<CartItem>>("cart") ?? new List<CartItem>();
            var book = _books.Get(id);
            if (book is null) return RedirectToPage();
            var item = cart.FirstOrDefault(i => i.BookId == id);
            if (item is null)
                cart.Add(new CartItem{ BookId = id, Title = book.Title, Price = book.Price, Quantity = 1 });
            else
                item.Quantity += 1;
            HttpContext.Session.SetObjectAsJson("cart", cart);
            return RedirectToPage();
        }

        public IActionResult OnPostRemove(int id)
        {
            var cart = HttpContext.Session.GetObjectFromJson<List<CartItem>>("cart") ?? new List<CartItem>();
            cart.RemoveAll(i => i.BookId == id);
            HttpContext.Session.SetObjectAsJson("cart", cart);
            return RedirectToPage();
        }

        public IActionResult OnPostClear()
        {
            HttpContext.Session.Remove("cart");
            return RedirectToPage();
        }
    }
}
