using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using OnlineBookStore.Data;
using OnlineBookStore.Models;

namespace OnlineBookStore.Pages.Books
{
    [Authorize(Roles="Admin")]
    public class CreateModel : PageModel
    {
        private readonly IBookRepository _repo;
        public CreateModel(IBookRepository repo) => _repo = repo;

        [BindProperty] public Book Book { get; set; } = new();

        public void OnGet(){}

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid) return Page();
            Book.Id = _repo.NextId();
            _repo.Add(Book);
            return RedirectToAction("Index", "Books");
        }
    }
}
