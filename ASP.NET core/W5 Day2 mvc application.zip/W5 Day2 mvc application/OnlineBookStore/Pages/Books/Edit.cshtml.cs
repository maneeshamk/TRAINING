using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using OnlineBookStore.Data;
using OnlineBookStore.Models;

namespace OnlineBookStore.Pages.Books
{
    [Authorize(Roles="Admin")]
    public class EditModel : PageModel
    {
        private readonly IBookRepository _repo;
        public EditModel(IBookRepository repo) => _repo = repo;

        [BindProperty] public Book Book { get; set; } = new();

        public IActionResult OnGet(int id)
        {
            var b = _repo.Get(id);
            if (b is null) return NotFound();
            Book = b;
            return Page();
        }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid) return Page();
            _repo.Update(Book);
            return RedirectToAction("Index", "Books");
        }
    }
}
