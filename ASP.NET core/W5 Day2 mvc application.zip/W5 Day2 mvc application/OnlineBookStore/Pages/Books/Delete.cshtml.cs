using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using OnlineBookStore.Data;

namespace OnlineBookStore.Pages.Books
{
    [Authorize(Roles="Admin")]
    public class DeleteModel : PageModel
    {
        private readonly IBookRepository _repo;
        public DeleteModel(IBookRepository repo) => _repo = repo;

        public IActionResult OnPost(int id)
        {
            _repo.Delete(id);
            return RedirectToAction("Index", "Books");
        }
    }
}
