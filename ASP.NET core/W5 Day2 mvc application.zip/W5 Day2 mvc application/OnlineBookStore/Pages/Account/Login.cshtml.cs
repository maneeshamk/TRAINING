using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Security.Claims;
using OnlineBookStore.Data;

namespace OnlineBookStore.Pages.Account
{
    public class LoginModel : PageModel
    {
        private readonly IUserRepository _users;
        public LoginModel(IUserRepository users) => _users = users;

        [BindProperty] public string Username { get; set; } = string.Empty;
        [BindProperty] public string Password { get; set; } = string.Empty;

        public void OnGet(){}

        public async Task<IActionResult> OnPostAsync()
        {
            var user = _users.Find(Username);
            if (user is null || user.Password != Password)
            {
                ModelState.AddModelError("", "Invalid credentials");
                return Page();
            }

            var claims = new List<Claim>{
                new Claim(ClaimTypes.Name, user.Username),
                new Claim(ClaimTypes.Role, user.Role)
            };
            var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
            await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(identity));
            return RedirectToPage("/Index");
        }
    }
}
