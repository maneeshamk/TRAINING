using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using OnlineBookStore.Data;
using OnlineBookStore.Models;
using System.ComponentModel.DataAnnotations;

namespace OnlineBookStore.Pages.Account
{
    public class RegisterModel : PageModel
    {
        private readonly IUserRepository _users;
        public RegisterModel(IUserRepository users) => _users = users;

        [BindProperty, Required, StringLength(100)]
        public string Username { get; set; } = string.Empty;

        [BindProperty, Required, StringLength(100)]
        public string Password { get; set; } = string.Empty;

        public void OnGet(){}

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid) return Page();
            if (_users.Find(Username) != null)
            {
                ModelState.AddModelError("", "Username already exists");
                return Page();
            }
            _users.Add(new User{ Username = Username, Password = Password, Role="User" });
            return RedirectToPage("Login");
        }
    }
}
