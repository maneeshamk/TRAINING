using System.ComponentModel.DataAnnotations;

namespace OnlineBookStore.Validation
{
    [AttributeUsage(AttributeTargets.Property)]
    public sealed class PriceRangeAttribute : ValidationAttribute
    {
        private readonly decimal _min;
        private readonly decimal _max;

        public PriceRangeAttribute(double min, double max)
        {
            _min = (decimal)min;
            _max = (decimal)max;
        }

        public override bool IsValid(object? value)
        {
            if (value is null) return false;
            if (value is decimal d) return d >= _min && d <= _max;
            return false;
        }

        public override string FormatErrorMessage(string name) => $"{name} must be between {_min} and {_max}.";
    }
}
