using System.ComponentModel.DataAnnotations;
using System.Text.RegularExpressions;

namespace OnlineBookStore.Validation
{
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false)]
    public sealed class IsbnAttribute : ValidationAttribute
    {
        public override bool IsValid(object? value)
        {
            if (value is null) return false;
            var s = value.ToString()!.Replace("-", "").Replace(" ", "");
            // very simple ISBN-10/13 check (length + digits)
            if (s.Length is 10 or 13 && Regex.IsMatch(s, @"^\d{9}(\d|X)$|^\d{13}$"))
                return true;
            return false;
        }

        public override string FormatErrorMessage(string name) =>
            $"{name} must be a valid ISBN-10 or ISBN-13.";
    }
}
