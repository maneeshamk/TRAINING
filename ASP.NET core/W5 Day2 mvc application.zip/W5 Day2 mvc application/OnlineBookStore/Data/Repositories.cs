using OnlineBookStore.Models;

namespace OnlineBookStore.Data
{
    public interface IBookRepository
    {
        IEnumerable<Book> GetAll();
        Book? Get(int id);
        void Add(Book book);
        void Update(Book book);
        void Delete(int id);
        int NextId();
    }

    public interface IOrderRepository
    {
        Order Add(Order order);
        Order? Get(int id);
    }

    public interface IUserRepository
    {
        User? Find(string username);
        void Add(User user);
    }

    public static class DataSeeder
    {
        public static void Seed(IBookRepository repo)
        {
            if (repo.GetAll().Any()) return;
            var demo = new[]{
                new Book{ Id = repo.NextId(), Title="Clean Code", Author="Robert C. Martin", ISBN="9780132350884", Price=39.99m},
                new Book{ Id = repo.NextId(), Title="The Pragmatic Programmer", Author="Andy Hunt", ISBN="9780201616224", Price=29.99m},
                new Book{ Id = repo.NextId(), Title="Domain-Driven Design", Author="Eric Evans", ISBN="9780321125217", Price=49.99m}
            };
            foreach (var b in demo) repo.Add(b);
        }
    }

    public class BookRepository : IBookRepository
    {
        private readonly List<Book> _books = new();
        private int _id = 1;

        public IEnumerable<Book> GetAll() => _books.OrderBy(b => b.Title);
        public Book? Get(int id) => _books.FirstOrDefault(b => b.Id == id);
        public void Add(Book book) { _books.Add(book); _id = Math.Max(_id, book.Id + 1); }
        public void Update(Book book)
        {
            var existing = Get(book.Id);
            if (existing is null) return;
            existing.Title = book.Title;
            existing.Author = book.Author;
            existing.ISBN = book.ISBN;
            existing.Price = book.Price;
        }
        public void Delete(int id) => _books.RemoveAll(b => b.Id == id);
        public int NextId() => _id++;
    }

    public class OrderRepository : IOrderRepository
    {
        private readonly List<Order> _orders = new();
        private int _id = 1;
        public Order Add(Order order)
        {
            order.Id = _id++;
            _orders.Add(order);
            return order;
        }
        public Order? Get(int id) => _orders.FirstOrDefault(o => o.Id == id);
    }

    public class UserRepository : IUserRepository
    {
        private readonly List<User> _users = new(){
            new User{ Id=1, Username="admin", Password="admin", Role="Admin"}
        };

        public User? Find(string username) => _users.FirstOrDefault(u => u.Username.Equals(username, StringComparison.OrdinalIgnoreCase));
        public void Add(User user)
        {
            user.Id = _users.Count == 0 ? 1 : _users.Max(u=>u.Id)+1;
            _users.Add(user);
        }
    }
}
