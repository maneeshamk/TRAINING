using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using OnlineBookStore.Data;
using OnlineBookStore.Models;

namespace OnlineBookStore.Controllers
{
    [Authorize]
    public class OrdersController : Controller
    {
        private readonly IOrderRepository _orders;
        public OrdersController(IOrderRepository orders) => _orders = orders;

        [HttpGet]
        public IActionResult Summary()
        {
            var cart = HttpContext.Session.GetObjectFromJson<List<CartItem>>("cart") ?? new List<CartItem>();
            var order = new Order{ Items = cart, CustomerEmail = User.Identity?.Name ?? "user@example.com" };
            return View(order);
        }

        [HttpPost]
        public IActionResult Confirm([FromForm] string email)
        {
            var cart = HttpContext.Session.GetObjectFromJson<List<CartItem>>("cart") ?? new List<CartItem>();
            if (cart.Count == 0) return RedirectToAction("Index", "Books");
            var order = new Order{ Items = cart, CustomerEmail = email };
            _orders.Add(order);
            HttpContext.Session.Remove("cart");
            return View("Confirmation", order);
        }
    }
}
