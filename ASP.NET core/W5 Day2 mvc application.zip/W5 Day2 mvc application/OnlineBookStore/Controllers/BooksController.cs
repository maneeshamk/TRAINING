using Microsoft.AspNetCore.Mvc;
using OnlineBookStore.Data;

namespace OnlineBookStore.Controllers
{
    // custom route with constraint on id
    [Route("catalog")]
    public class BooksController : Controller
    {
        private readonly IBookRepository _repo;
        public BooksController(IBookRepository repo) => _repo = repo;

        [HttpGet("books")]
        public IActionResult Index() => View(_repo.GetAll());

        [HttpGet("book/{id:int:min(1)}")]
        public IActionResult Details(int id)
        {
            var book = _repo.Get(id);
            if (book is null) return NotFound();
            return View(book);
        }
    }
}
