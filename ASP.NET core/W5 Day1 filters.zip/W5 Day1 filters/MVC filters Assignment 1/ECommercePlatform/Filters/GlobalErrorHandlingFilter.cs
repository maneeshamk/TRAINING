using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Logging;

namespace ECommercePlatform.Filters
{
    public class GlobalErrorHandlingFilter : IExceptionFilter
    {
        private readonly ILogger<GlobalErrorHandlingFilter> _logger;

        public GlobalErrorHandlingFilter(ILogger<GlobalErrorHandlingFilter> logger)
        {
            _logger = logger;
        }

        public void OnException(ExceptionContext context)
        {
            _logger.LogError(context.Exception, "Unhandled exception occurred");

            context.Result = new ViewResult
            {
                ViewName = "~/Views/Shared/Error.cshtml"
            };

            context.ExceptionHandled = true;
        }
    }
}
