namespace ECommercePlatform.Services
{
    public class AuthService : IAuthService
    {
        private bool _isLoggedIn = false;

        public bool IsUserLoggedIn() => _isLoggedIn;

        public void Login(string username, string password)
        {
            // Simplified authentication
            if (username == "admin" && password == "password")
                _isLoggedIn = true;
        }

        public void Logout()
        {
            _isLoggedIn = false;
        }
    }
}
