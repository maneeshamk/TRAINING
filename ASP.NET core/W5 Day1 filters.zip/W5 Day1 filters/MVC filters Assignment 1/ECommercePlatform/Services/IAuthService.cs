namespace ECommercePlatform.Services
{
    public interface IAuthService
    {
        bool IsUserLoggedIn();
        void Login(string username, string password);
        void Logout();
    }
}
