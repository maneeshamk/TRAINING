using Microsoft.AspNetCore.Mvc;
using ECommercePlatform.Models;

namespace ECommercePlatform.Controllers
{
    public class OrdersController : Controller
    {
        private static List<Order> _orders = new();

        public IActionResult Index() => View(_orders);

        public IActionResult Checkout()
        {
            var order = new Order
            {
                Id = _orders.Count + 1,
                User = "admin",
                Products = new List<Product>{ new Product{ Id=1, Name="Laptop", Price=55000 } }
            };
            _orders.Add(order);
            return View(order);
        }
    }
}
