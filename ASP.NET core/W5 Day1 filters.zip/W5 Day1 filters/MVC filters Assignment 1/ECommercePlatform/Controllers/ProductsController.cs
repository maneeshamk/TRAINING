using Microsoft.AspNetCore.Mvc;
using ECommercePlatform.Models;

namespace ECommercePlatform.Controllers
{
    public class ProductsController : Controller
    {
        private static List<Product> _products = new()
        {
            new Product{ Id=1, Name="Laptop", Price=55000 },
            new Product{ Id=2, Name="Smartphone", Price=25000 }
        };

        public IActionResult Index() => View(_products);

        public IActionResult Details(int id)
        {
            var product = _products.FirstOrDefault(p => p.Id == id);
            return View(product);
        }
    }
}
