using Microsoft.AspNetCore.Mvc;
using ECommercePlatform.Models;
using ECommercePlatform.Services;

namespace ECommercePlatform.Controllers
{
    public class AccountController : Controller
    {
        private readonly IAuthService _authService;

        public AccountController(IAuthService authService)
        {
            _authService = authService;
        }

        public IActionResult Login() => View();

        [HttpPost]
        public IActionResult Login(User user)
        {
            _authService.Login(user.Username!, user.Password!);
            if (_authService.IsUserLoggedIn())
                return RedirectToAction("Index", "Home");

            ViewBag.Error = "Invalid login";
            return View();
        }

        public IActionResult Logout()
        {
            _authService.Logout();
            return RedirectToAction("Index", "Home");
        }
    }
}
