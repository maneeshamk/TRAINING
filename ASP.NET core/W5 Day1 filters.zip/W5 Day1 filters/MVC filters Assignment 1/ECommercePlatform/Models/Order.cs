namespace ECommercePlatform.Models
{
    public class Order
    {
        public int Id { get; set; }
        public string? User { get; set; }
        public List<Product>? Products { get; set; }
        public decimal TotalAmount => Products?.Sum(p => p.Price) ?? 0;
    }
}
