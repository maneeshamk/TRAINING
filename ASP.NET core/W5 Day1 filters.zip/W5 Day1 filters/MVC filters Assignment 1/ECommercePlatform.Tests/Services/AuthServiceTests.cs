using Xunit;
using ECommercePlatform.Services;

namespace ECommercePlatform.Tests.Services
{
    public class AuthServiceTests
    {
        [Fact]
        public void Login_ShouldAuthenticate_WhenCredentialsAreValid()
        {
            // Arrange
            var service = new AuthService();

            // Act
            service.Login("admin", "password");

            // Assert
            Assert.True(service.IsUserLoggedIn());
        }

        [Fact]
        public void Login_ShouldFail_WhenCredentialsAreInvalid()
        {
            // Arrange
            var service = new AuthService();

            // Act
            service.Login("wrong", "user");

            // Assert
            Assert.False(service.IsUserLoggedIn());
        }

        [Fact]
        public void Logout_ShouldSetLoggedInToFalse()
        {
            // Arrange
            var service = new AuthService();
            service.Login("admin", "password");

            // Act
            service.Logout();

            // Assert
            Assert.False(service.IsUserLoggedIn());
        }
    }
}
