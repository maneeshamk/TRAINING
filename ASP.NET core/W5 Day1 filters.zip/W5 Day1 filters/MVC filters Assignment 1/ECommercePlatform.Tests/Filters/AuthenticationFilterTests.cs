using Xunit;
using Moq;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using Microsoft.AspNetCore.Mvc.Abstractions;
using ECommercePlatform.Filters;
using ECommercePlatform.Services;

namespace ECommercePlatform.Tests.Filters
{
    public class AuthenticationFilterTests
    {
        [Fact]
        public void OnAuthorization_ShouldRedirectToLogin_WhenUserNotLoggedIn()
        {
            // Arrange
            var authService = new Mock<IAuthService>();
            authService.Setup(a => a.IsUserLoggedIn()).Returns(false);

            var filter = new AuthenticationFilter(authService.Object);

            var httpContext = new DefaultHttpContext();
            var actionContext = new ActionContext(httpContext, new RouteData(), new ActionDescriptor());

            var context = new AuthorizationFilterContext(actionContext, new List<IFilterMetadata>());

            // Act
            filter.OnAuthorization(context);

            // Assert
            Assert.IsType<RedirectToActionResult>(context.Result);

            var result = context.Result as RedirectToActionResult;
            Assert.Equal("Login", result?.ActionName);
            Assert.Equal("Account", result?.ControllerName);
        }

        [Fact]
        public void OnAuthorization_ShouldAllowAccess_WhenUserIsLoggedIn()
        {
            // Arrange
            var authService = new Mock<IAuthService>();
            authService.Setup(a => a.IsUserLoggedIn()).Returns(true);

            var filter = new AuthenticationFilter(authService.Object);

            var httpContext = new DefaultHttpContext();
            var actionContext = new ActionContext(httpContext, new RouteData(), new ActionDescriptor());

            var context = new AuthorizationFilterContext(actionContext, new List<IFilterMetadata>());

            // Act
            filter.OnAuthorization(context);

            // Assert
            Assert.Null(context.Result); // no redirect
        }
    }
}
