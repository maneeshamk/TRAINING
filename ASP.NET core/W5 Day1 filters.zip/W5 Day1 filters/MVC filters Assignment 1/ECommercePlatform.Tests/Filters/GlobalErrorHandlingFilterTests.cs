using Xunit;
using Microsoft.Extensions.Logging;
using Moq;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using Microsoft.AspNetCore.Mvc.Abstractions;
using ECommercePlatform.Filters;

namespace ECommercePlatform.Tests.Filters
{
    public class GlobalErrorHandlingFilterTests
    {
        [Fact]
        public void OnException_ShouldHandleAndSetErrorView()
        {
            // Arrange
            var logger = new Mock<ILogger<GlobalErrorHandlingFilter>>();
            var filter = new GlobalErrorHandlingFilter(logger.Object);

            var httpContext = new DefaultHttpContext();
            var actionContext = new ActionContext(httpContext, new RouteData(), new ActionDescriptor());

            var context = new ExceptionContext(actionContext, new List<IFilterMetadata>())
            {
                Exception = new Exception("Test Exception")
            };

            // Act
            filter.OnException(context);

            // Assert
            Assert.True(context.ExceptionHandled);
            Assert.IsType<ViewResult>(context.Result);

            var result = context.Result as ViewResult;
            Assert.Equal("~/Views/Shared/Error.cshtml", result?.ViewName);
        }
    }
}
