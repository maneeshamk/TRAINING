using Xunit;
using Microsoft.Extensions.Logging;
using Moq;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using Microsoft.AspNetCore.Mvc.Abstractions;
using ECommercePlatform.Filters;

namespace ECommercePlatform.Tests.Filters
{
    public class LoggingFilterTests
    {
        [Fact]
        public void OnActionExecuting_ShouldLogInformation()
        {
            // Arrange
            var logger = new Mock<ILogger<LoggingFilter>>();
            var filter = new LoggingFilter(logger.Object);

            var httpContext = new DefaultHttpContext();
            var actionContext = new ActionContext(httpContext, new RouteData(), new ActionDescriptor());

            var context = new ActionExecutingContext(
                actionContext,
                new List<IFilterMetadata>(),
                new Dictionary<string, object>(),
                new object());

            // Act
            filter.OnActionExecuting(context);

            // Assert
            logger.Verify(
                l => l.Log(
                    LogLevel.Information,
                    It.IsAny<EventId>(),
                    It.IsAny<It.IsAnyType>(),
                    null,
                    It.IsAny<Func<It.IsAnyType, Exception?, string>>()),
                Times.Once);
        }

        [Fact]
        public void OnActionExecuted_ShouldLogInformation()
        {
            // Arrange
            var logger = new Mock<ILogger<LoggingFilter>>();
            var filter = new LoggingFilter(logger.Object);

            var httpContext = new DefaultHttpContext();
            var actionContext = new ActionContext(httpContext, new RouteData(), new ActionDescriptor());

            var context = new ActionExecutedContext(
                actionContext,
                new List<IFilterMetadata>(),
                new object());

            // Act
            filter.OnActionExecuted(context);

            // Assert
            logger.Verify(
                l => l.Log(
                    LogLevel.Information,
                    It.IsAny<EventId>(),
                    It.IsAny<It.IsAnyType>(),
                    null,
                    It.IsAny<Func<It.IsAnyType, Exception?, string>>()),
                Times.Once);
        }
    }
}
