using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Moq;
using OnlineBankingApp.Filters;
using OnlineBankingApp.Services;
using OnlineBankingApp.Tests.Utils;
using Xunit;

namespace OnlineBankingApp.Tests.Filters
{
    public class ErrorHandlingFilterTests
    {
        [Fact]
        public void Handles_Exception_And_Returns_Error_View()
        {
            // Arrange
            var loggerMock = new Mock<ILoggingService>();
            var filter = new ErrorHandlingFilter(loggerMock.Object);

            var actionContext = TestHelper.CreateActionContext();
            var exceptionContext = new ExceptionContext(actionContext, new List<IFilterMetadata>())
            {
                Exception = new Exception("Test Exception")
            };

            // Act
            filter.OnException(exceptionContext);

            // Assert
            Assert.IsType<ViewResult>(exceptionContext.Result);
            var viewResult = (ViewResult)exceptionContext.Result;
            Assert.Equal("Error", viewResult.ViewName);
        }
    }
}
