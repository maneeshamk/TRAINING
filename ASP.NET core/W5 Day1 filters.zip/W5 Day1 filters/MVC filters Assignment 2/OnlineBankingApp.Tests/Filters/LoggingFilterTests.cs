using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Filters;
using OnlineBankingApp.Filters;
using OnlineBankingApp.Tests.Utils;
using Xunit;

namespace OnlineBankingApp.Tests.Filters
{
    public class LoggingFilterTests
    {
        [Fact]
        public void OnActionExecuting_LogsAction()
        {
            // Arrange
            var httpContext = new DefaultHttpContext();
            var context = TestHelper.CreateActionContext(httpContext);

            var actionArguments = new Dictionary<string, object?>();
            var actionContext = new ActionExecutingContext(
                context,
                new List<IFilterMetadata>(),
                actionArguments,
                new object()
            );

            var filter = new LoggingFilter(new FakeLoggingService());

            // Act
            filter.OnActionExecuting(actionContext);

            // Assert
            Assert.NotNull(actionContext);
        }
    }
}
