using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Filters;
using OnlineBankingApp.Filters;
using OnlineBankingApp.Tests.Utils;
using Xunit;
using Microsoft.AspNetCore.Mvc.Abstractions;

namespace OnlineBankingApp.Tests.Filters
{
    public class AuthenticationFilterTests
    {
        [Fact]
        public void OnAuthentication_ValidUser_AllowsAccess()
        {
            // Arrange
            var httpContext = new DefaultHttpContext();
            var context = TestHelper.CreateActionContext(httpContext);
            var authContext = new AuthenticationContext(context, new List<IFilterMetadata>());

            var filter = new AuthenticationFilter();

            // Act
            filter.OnAuthentication(authContext);

            // Assert
            Assert.Null(authContext.Result);
        }
    }
}
