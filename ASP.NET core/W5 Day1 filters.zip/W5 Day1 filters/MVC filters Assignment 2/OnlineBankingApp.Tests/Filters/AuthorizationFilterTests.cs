using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Filters;
using OnlineBankingApp.Filters;
using OnlineBankingApp.Tests.Utils;
using Xunit;

namespace OnlineBankingApp.Tests.Filters
{
    public class AuthorizationFilterTests
    {
        [Fact]
        public void OnAuthorization_UserInRole_AllowsAccess()
        {
            // Arrange
            var httpContext = new DefaultHttpContext();
            httpContext.User = new System.Security.Claims.ClaimsPrincipal(
                new System.Security.Claims.ClaimsIdentity(new[] {
                    new System.Security.Claims.Claim("role", "Admin")
                }, "TestAuthType")
            );

            var context = TestHelper.CreateActionContext(httpContext);
            var authContext = new AuthorizationFilterContext(
                context,
                new List<IFilterMetadata>()
            );

            var filter = new AuthorizationFilter("Admin");

            // Act
            filter.OnAuthorization(authContext);

            // Assert
            Assert.Null(authContext.Result);
        }

        [Fact]
        public void OnAuthorization_UserNotInRole_BlocksAccess()
        {
            // Arrange
            var httpContext = new DefaultHttpContext();
            httpContext.User = new System.Security.Claims.ClaimsPrincipal(
                new System.Security.Claims.ClaimsIdentity(new[] {
                    new System.Security.Claims.Claim("role", "User")
                }, "TestAuthType")
            );

            var context = TestHelper.CreateActionContext(httpContext);
            var authContext = new AuthorizationFilterContext(
                context,
                new List<IFilterMetadata>()
            );

            var filter = new AuthorizationFilter("Admin");

            // Act
            filter.OnAuthorization(authContext);

            // Assert
            Assert.IsType<ForbidResult>(authContext.Result);
        }
    }
}
