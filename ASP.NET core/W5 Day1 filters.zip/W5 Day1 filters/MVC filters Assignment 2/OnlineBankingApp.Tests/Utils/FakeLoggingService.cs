using OnlineBankingApp.Services;

namespace OnlineBankingApp.Tests.Utils
{
    public class FakeLoggingService : ILoggingService
    {
        public void LogInfo(string message)
        {
            // no-op for unit tests
        }

        public void LogError(string message, Exception? exception)
        {
            // no-op for unit tests
        }
    }
}
