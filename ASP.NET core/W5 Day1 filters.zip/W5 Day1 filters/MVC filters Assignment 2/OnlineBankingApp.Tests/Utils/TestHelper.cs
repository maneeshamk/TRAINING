using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Routing;
using Microsoft.AspNetCore.Mvc.Abstractions; // ✅ ActionDescriptor lives here


namespace OnlineBankingApp.Tests.Utils
{
    public static class TestHelper
    {
        // Parameterless version
        public static ActionContext CreateActionContext()
        {
            var httpContext = new DefaultHttpContext();
            var routeData = new RouteData();
            var actionDescriptor = new ActionDescriptor();

            return new ActionContext(httpContext, routeData, actionDescriptor);
        }

        // Overload that accepts HttpContext
        public static ActionContext CreateActionContext(HttpContext httpContext)
        {
            var routeData = new RouteData();
            var actionDescriptor = new ActionDescriptor();

            return new ActionContext(httpContext, routeData, actionDescriptor);
        }
    }
}
