using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using OnlineBankingApp.Filters;
using OnlineBankingApp.Services;

var builder = WebApplication.CreateBuilder(args);

// MVC + global filters (logging + error handling)
builder.Services.AddControllersWithViews(options =>
{
    options.Filters.Add<LoggingFilter>();
    options.Filters.Add<ErrorHandlingFilter>();
});

// AuthN/AuthZ (cookie)
builder.Services
    .AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(o =>
    {
        o.LoginPath = "/Account/Login";
        o.AccessDeniedPath = "/Account/Denied";
    });

builder.Services.AddAuthorization();

// DI: services + filters (so filters can get services)
builder.Services.AddSingleton<ILoggingService, LoggingService>();
builder.Services.AddSingleton<IAuthService, AuthService>();

builder.Services.AddScoped<AuthenticationFilter>();
builder.Services.AddScoped<AuthorizationFilter>();
builder.Services.AddScoped<LoggingFilter>();
builder.Services.AddScoped<ErrorHandlingFilter>();

var app = builder.Build();

// Middleware
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}
app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseAuthentication();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Banking}/{action=Index}/{id?}");

app.Run();
