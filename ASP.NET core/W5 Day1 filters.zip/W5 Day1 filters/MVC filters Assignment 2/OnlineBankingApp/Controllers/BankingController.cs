using Microsoft.AspNetCore.Mvc;
using OnlineBankingApp.Filters;
using OnlineBankingApp.Models;
using System.Collections.Concurrent;

namespace OnlineBankingApp.Controllers;

[ServiceFilter(typeof(AuthenticationFilter))]
public class BankingController : Controller
{
    // Static in-memory data (simulates a DB)
    internal static readonly ConcurrentDictionary<int, Account> _accounts = new();
    internal static readonly ConcurrentDictionary<int, Transaction> _tx = new();
    private static int _nextAccId = 1;
    private static int _nextTxId = 1;

    public BankingController()
    {
        // Seed only once
        if (_accounts.IsEmpty)
        {
            var a1 = new Account { Id = _nextAccId++, OwnerUsername = "admin", Balance = 5000m };
            var a2 = new Account { Id = _nextAccId++, OwnerUsername = "user", Balance = 1200m };
            _accounts[a1.Id] = a1;
            _accounts[a2.Id] = a2;
        }
    }

    // 📌 Home - show logged-in user accounts
    public IActionResult Index()
    {
        var user = User.Identity!.Name!;
        var accounts = _accounts.Values
            .Where(a => a.OwnerUsername.Equals(user, StringComparison.OrdinalIgnoreCase))
            .ToList();

        return View(accounts);
    }

    // 📌 Transactions for account
    public IActionResult Transactions(int id)
    {
        var items = _tx.Values
            .Where(t => t.FromAccountId == id || t.ToAccountId == id)
            .OrderByDescending(t => t.Timestamp)
            .ToList();

        ViewBag.AccountId = id;
        return View(items);
    }

    // 📌 Transfer GET
    [HttpGet]
    public IActionResult Transfer()
    {
        var currentUser = User.Identity!.Name;

        ViewBag.MyAccounts = _accounts.Values
            .Where(a => a.OwnerUsername.Equals(currentUser, StringComparison.OrdinalIgnoreCase))
            .ToList();

        ViewBag.AllAccounts = _accounts.Values.ToList();
        return View();
    }

    // 📌 Transfer POST
    [HttpPost]
    public IActionResult Transfer(int fromAccountId, int toAccountId, decimal amount)
    {
        if (fromAccountId == toAccountId) { ModelState.AddModelError("", "Accounts must differ."); }
        if (amount <= 0) { ModelState.AddModelError("", "Amount must be positive."); }

        if (!ModelState.IsValid)
        {
            return Transfer();
        }

        if (!_accounts.TryGetValue(fromAccountId, out var from) || !_accounts.TryGetValue(toAccountId, out var to))
            throw new InvalidOperationException("Account not found.");

        if (!from.OwnerUsername.Equals(User.Identity!.Name, StringComparison.OrdinalIgnoreCase))
            return Forbid();

        if (from.Balance < amount) { ModelState.AddModelError("", "Insufficient funds."); return Transfer(); }

        // Perform transfer
        from.Balance -= amount;
        to.Balance += amount;

        var tx = new Transaction
        {
            Id = _nextTxId++,
            FromAccountId = fromAccountId,
            ToAccountId = toAccountId,
            Amount = amount,
            PerformedBy = User.Identity!.Name!,
            Timestamp = DateTime.UtcNow
        };
        _tx[tx.Id] = tx;

        TempData["Msg"] = "Transfer successful.";
        return RedirectToAction(nameof(Transactions), new { id = fromAccountId });
    }

    // 📌 Admin-only: view all accounts
    [RequireRole("Admin")]
    public IActionResult AdminAllAccounts()
    {
        return View("Index", _accounts.Values.ToList());
    }

    // 📌 Utility: create a new account for a registered user
    public static void CreateUserAccount(string username, decimal initialBalance = 1000m)
    {
        var acc = new Account
        {
            Id = _nextAccId++,
            OwnerUsername = username,
            Balance = initialBalance
        };
        _accounts[acc.Id] = acc;
    }
}
