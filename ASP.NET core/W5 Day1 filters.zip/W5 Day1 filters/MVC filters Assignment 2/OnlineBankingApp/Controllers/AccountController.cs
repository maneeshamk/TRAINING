using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using OnlineBankingApp.Models;
using OnlineBankingApp.Services;
using System.Security.Claims;

namespace OnlineBankingApp.Controllers;

public class AccountController : Controller
{
    private readonly IAuthService _auth;

    public AccountController(IAuthService auth) => _auth = auth;

    [HttpGet]
    public IActionResult Login(string? returnUrl = null) => View(model: returnUrl);

    [HttpPost]
    public async Task<IActionResult> Login(string username, string password, string? returnUrl = null)
    {
        var user = _auth.ValidateUser(username, password);
        if (user is null)
        {
            ViewBag.Error = "Invalid credentials.";
            return View(model: returnUrl);
        }

        var claims = new List<Claim>
        {
            new Claim(ClaimTypes.Name, user.Username),
            new Claim(ClaimTypes.Role, user.Role)
        };
        var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
        await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(identity));

        if (!string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl))
            return Redirect(returnUrl);

        return RedirectToAction("Index", "Banking");
    }

    [HttpGet]
    public IActionResult Register() => View();

    [HttpPost]
public IActionResult Register(string username, string password, string role = "Customer")
{
    var ok = _auth.Register(username, password, role);
    if (!ok)
    {
        ViewBag.Error = "Username already exists.";
        return View();
    }

    // Create a new bank account automatically
    BankingController.CreateUserAccount(username, 1000m);

    return RedirectToAction(nameof(Login));
}


    [HttpPost]
    public async Task<IActionResult> Logout()
    {
        await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
        return RedirectToAction(nameof(Login));
    }

    [HttpGet]
    public IActionResult Denied() => Content("Access denied: you do not have permission.");
}
