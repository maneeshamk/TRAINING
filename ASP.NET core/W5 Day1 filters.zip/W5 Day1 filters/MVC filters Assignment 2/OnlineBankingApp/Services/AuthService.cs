﻿using OnlineBankingApp.Models;
using System.Collections.Concurrent;
using System.Security.Cryptography;
using System.Text;

namespace OnlineBankingApp.Services;

public class AuthService : IAuthService
{
    // In-memory users for demo. (username -> User)
    private readonly ConcurrentDictionary<string, User> _users = new();

    public AuthService()
    {
        // seed
        Register("admin", "admin123", "Admin");
        Register("user", "user123", "Customer");
    }

    public IEnumerable<User> GetAllUsers() => _users.Values;

    public bool Register(string username, string password, string role)
    {
        var user = new User
        {
            Username = username,
            PasswordHash = Hash(password),
            Role = string.IsNullOrWhiteSpace(role) ? "Customer" : role
        };
        return _users.TryAdd(username.ToLowerInvariant(), user);
    }

    public User? ValidateUser(string username, string password)
    {
        if (_users.TryGetValue(username.ToLowerInvariant(), out var u))
        {
            return u.PasswordHash == Hash(password) ? u : null;
        }
        return null;
    }

    private static string Hash(string input)
    {
        using var sha = SHA256.Create();
        var bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(input));
        return Convert.ToHexString(bytes);
    }
}
