﻿using Microsoft.AspNetCore.Mvc.Filters;
using OnlineBankingApp.Services;

namespace OnlineBankingApp.Filters
{
    public class LoggingFilter : IActionFilter
    {
        private readonly ILoggingService _logger;

        public LoggingFilter(ILoggingService logger)
        {
            _logger = logger;
        }

        public void OnActionExecuting(ActionExecutingContext context)
        {
            _logger.LogInfo($"Executing action: {context.ActionDescriptor.DisplayName}");
        }

        public void OnActionExecuted(ActionExecutedContext context)
        {
            if (context.Exception != null)
            {
                _logger.LogError(
                    $"Exception in action: {context.ActionDescriptor.DisplayName}",
                    context.Exception
                );
            }
            else
            {
                _logger.LogInfo($"Executed action: {context.ActionDescriptor.DisplayName}");
            }
        }
    }
}
