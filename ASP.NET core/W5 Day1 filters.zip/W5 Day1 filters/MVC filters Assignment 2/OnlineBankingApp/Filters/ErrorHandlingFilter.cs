﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using OnlineBankingApp.Models;
using OnlineBankingApp.Services;
using System.Diagnostics;

namespace OnlineBankingApp.Filters;

public class ErrorHandlingFilter : IExceptionFilter
{
    private readonly ILoggingService _logger;

    public ErrorHandlingFilter(ILoggingService logger) => _logger = logger;

    public void OnException(ExceptionContext context)
    {
        // Log details
        _logger.LogError($"Unhandled: {context.Exception.Message}", context.Exception);

        // Mark exception as handled
        context.ExceptionHandled = true;

        // Try to supply ErrorViewModel if your view expects it
        var errorModel = new ErrorViewModel
        {
            RequestId = Activity.Current?.Id ?? context.HttpContext.TraceIdentifier
        };

        context.Result = new ViewResult
        {
            ViewName = "~/Views/Shared/Error.cshtml",
            ViewData = new ViewDataDictionary<ErrorViewModel>(
                new Microsoft.AspNetCore.Mvc.ModelBinding.EmptyModelMetadataProvider(),
                context.ModelState)
            {
                Model = errorModel
            }
        };
    }
}
