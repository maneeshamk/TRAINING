﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System.Security.Claims;

namespace OnlineBankingApp.Filters;

public class AuthorizationFilter : IAuthorizationFilter
{
    private readonly string _requiredRole;

    // Use via attribute like: [ServiceFilter(typeof(AuthorizationFilter), IsReusable=false)]
    // but we need a role; so we'll provide helper attribute below.
    public AuthorizationFilter() { _requiredRole = string.Empty; }
    public AuthorizationFilter(string requiredRole) { _requiredRole = requiredRole ?? string.Empty; }

    public void OnAuthorization(AuthorizationFilterContext context)
    {
        if (!string.IsNullOrEmpty(_requiredRole))
        {
            var hasRole = context.HttpContext.User.Claims
                .Any(c => c.Type == ClaimTypes.Role && c.Value.Equals(_requiredRole, StringComparison.OrdinalIgnoreCase));
            if (!hasRole)
            {
                context.Result = new RedirectToActionResult("Denied", "Account", null);
            }
        }
    }
}

// Convenience attribute to plug role into DI-created filter
[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
public class RequireRoleAttribute : TypeFilterAttribute
{
    public RequireRoleAttribute(string role)
        : base(typeof(AuthorizationFilter))
    {
        Arguments = new object[] { role };
    }
}
