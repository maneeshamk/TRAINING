﻿namespace OnlineBankingApp.Models;

public class Account
{
    public int Id { get; set; }
    public string OwnerUsername { get; set; } = "";
    public decimal Balance { get; set; }
}
