﻿using Microsoft.AspNetCore.Mvc;
using UserRegistrationSystem.Models;

namespace UserRegistrationSystem.Controllers
{
    public class AccountController : Controller
    {
        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Register(UserRegistration user)
        {
            if (ModelState.IsValid)
            {
                return RedirectToAction("Success");
            }
            return View(user);
        }

        public IActionResult Success()
        {
            return Content("Registration successful");
        }
    }
}
