﻿using Microsoft.AspNetCore.Html;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace CustomerFeedbackPortal.Helpers
{
    public static class HtmlHelperExtensions
    {
        public static IHtmlContent StyledInput(this IHtmlHelper htmlHelper, string name, string placeholder)
        {
            return htmlHelper.TextBox(name, null, new { @class = "form-control", placeholder = placeholder });
        }
    }
}
