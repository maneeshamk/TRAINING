using ECommerceApp.RouteConstraints;
using Microsoft.AspNetCore.Routing;

var builder = WebApplication.CreateBuilder(args);

// MVC
builder.Services.AddControllersWithViews();

// Register custom route constraints
builder.Services.Configure<RouteOptions>(options =>
{
    options.ConstraintMap.Add("categoryConstraint", typeof(CategoryConstraint));
    options.ConstraintMap.Add("priceRangeConstraint", typeof(PriceRangeConstraint));
});

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();
app.UseAuthorization();

app.MapControllerRoute(
    name: "productDetails",
    pattern: "Products/{category}/{id:int}",
    defaults: new { controller = "Products", action = "Details" }
);

app.MapControllerRoute(
    name: "filter",
    pattern: "Products/Filter/{category}/{priceRange}",
    defaults: new { controller = "Products", action = "Filter" }
);

app.MapControllerRoute(
    name: "checkout",
    pattern: "Checkout",
    defaults: new { controller = "Cart", action = "Checkout" });

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();