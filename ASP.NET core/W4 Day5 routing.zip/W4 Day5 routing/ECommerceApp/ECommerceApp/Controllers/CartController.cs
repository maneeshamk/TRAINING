using ECommerceApp.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace ECommerceApp.Controllers
{
    public class CartController : Controller
    {
        // Simple in-memory cart for demo (shared across requests - not for production)
        private static readonly List<CartItem> Cart = new();

        public IActionResult Index()
        {
            return View(Cart);
        }

        [HttpPost]
        public IActionResult Add(int productId, string productName, decimal price, int qty = 1)
        {
            var existing = Cart.Find(c => c.ProductId == productId);
            if (existing != null)
            {
                existing.Quantity += qty;
            }
            else
            {
                Cart.Add(new CartItem { ProductId = productId, ProductName = productName, Price = price, Quantity = qty });
            }
            return RedirectToAction("Index");
        }
        [HttpPost]
        public IActionResult Remove(int productId)
        {
            var item = Cart.Find(c => c.ProductId == productId);
            if (item != null)
            {
                Cart.Remove(item);
            }
            return RedirectToAction("Index");
        }

        // Dynamic routing example: redirect to login if user is not authenticated
        public IActionResult Checkout()
        {
            // Using built-in authentication state - in this demo we don't configure authentication,
            // so User.Identity.IsAuthenticated will be false. In a real app you would use actual auth.
            if (!User.Identity?.IsAuthenticated ?? true)
            {
                TempData["ReturnUrl"] = Url.Action("Checkout", "Cart");
                return RedirectToAction("Login", "Account");
            }

            // Proceed to checkout view (if authenticated)
            return View();
        }
    }
}
