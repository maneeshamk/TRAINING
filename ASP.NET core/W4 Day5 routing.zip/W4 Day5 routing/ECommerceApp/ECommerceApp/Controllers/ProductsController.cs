using ECommerceApp.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;

namespace ECommerceApp.Controllers
{
    public class ProductsController : Controller
    {
        // Demo in-memory products
        private static readonly List<Product> Products = new()
        {
            new Product { Id = 1, Category = "electronics", Name = "Laptop", Price = 750, Description = "Lightweight laptop" },
            new Product { Id = 2, Category = "electronics", Name = "Headphones", Price = 120, Description = "Noise-cancelling" },
            new Product { Id = 3, Category = "fashion", Name = "Denim Jacket", Price = 80, Description = "Stylish jacket" },
            new Product { Id = 4, Category = "books", Name = "C# Programming", Price = 35, Description = "Learn C# in depth" },
            new Product { Id = 5, Category = "books", Name = "Design Patterns", Price = 45, Description = "Classic patterns" }
        };

        public IActionResult Index()
        {
            return View(Products);
        }

        // Matches route /Products/{category}/{id}
        public IActionResult Details(string category, int id)
        {
            var product = Products.FirstOrDefault(p => p.Category == category && p.Id == id);
            if (product == null) return NotFound();
            return View(product);
        }

        // Matches route /Products/Filter/{category}/{priceRange}
        public IActionResult Filter(string category, string priceRange)
        {
            var rangeParts = priceRange.Split('-', 2);
            if (rangeParts.Length != 2) return BadRequest("Invalid price range.");
            if (!int.TryParse(rangeParts[0], out var min) || !int.TryParse(rangeParts[1], out var max)) return BadRequest("Invalid price numbers.");

            var filtered = Products.Where(p => p.Category == category && p.Price >= min && p.Price <= max).ToList();
            ViewData["Category"] = category;
            ViewData["PriceRange"] = priceRange;
            return View(filtered);
        }
    }
}
