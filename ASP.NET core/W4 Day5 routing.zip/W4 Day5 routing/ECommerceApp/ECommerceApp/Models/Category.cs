namespace ECommerceApp.Models
{
    public class Category
    {
        public string Name { get; set; } = "";
    }
}
