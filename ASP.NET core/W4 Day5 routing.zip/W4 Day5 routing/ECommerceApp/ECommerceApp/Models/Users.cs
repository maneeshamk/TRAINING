using System.ComponentModel.DataAnnotations;

namespace ECommerceApp.Models
{
    public class User
    {
        [Required(ErrorMessage = "Username is required")]
        [StringLength(50, MinimumLength = 3, ErrorMessage = "Username must be 3-50 characters")]
        public string Username { get; set; } = "";

        [Required(ErrorMessage = "Role is required")]
        public string Role { get; set; } = "Customer";

        public bool IsLoggedIn { get; set; } = false;
    }
}
