using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using System;

namespace ECommerceApp.RouteConstraints
{
    public class CategoryConstraint : IRouteConstraint
    {
        // Allowed categories for demo
        private static readonly string[] AllowedCategories = { "electronics", "fashion", "books" };

        public bool Match(HttpContext? httpContext, IRouter? route, string routeKey, RouteValueDictionary values, RouteDirection routeDirection)
        {
            if (!values.ContainsKey(routeKey)) return false;
            var category = values[routeKey]?.ToString()?.ToLowerInvariant() ?? "";
            return Array.Exists(AllowedCategories, c => c == category);
        }
    }
}
