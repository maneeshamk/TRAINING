using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using System.Text.RegularExpressions;

namespace ECommerceApp.RouteConstraints
{
    public class PriceRangeConstraint : IRouteConstraint
    {
        // Accepts patterns like 10-100 or 0-99999
        private static readonly Regex RangeRegex = new(@"^\d{1,6}-\d{1,6}$", RegexOptions.Compiled);

        public bool Match(HttpContext? httpContext, IRouter? route, string routeKey, RouteValueDictionary values, RouteDirection routeDirection)
        {
            if (!values.ContainsKey(routeKey)) return false;
            var val = values[routeKey]?.ToString() ?? "";
            if (!RangeRegex.IsMatch(val)) return false;

            var parts = val.Split('-', 2);
            if (int.TryParse(parts[0], out var min) && int.TryParse(parts[1], out var max))
            {
                return min <= max;
            }
            return false;
        }
    }
}
