using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;

namespace AdvancedRoutingApp.Models
{
    public class GuidConstraint : IRouteConstraint
    {
        public bool Match(HttpContext? httpContext,
                          IRouter? route,
                          string routeKey,
                          RouteValueDictionary values,
                          RouteDirection routeDirection)
        {
            if (values[routeKey] is string s)
            {
                return Guid.TryParse(s, out _);
            }
            return false;
        }
    }
}