using AdvancedRoutingApp.Models;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews();

// Register custom route constraints
builder.Services.Configure<RouteOptions>(options =>
{
    options.ConstraintMap.Add("myguid", typeof(GuidConstraint));
});

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();
app.UseAuthorization();

// Complex route: /Products/{category}/{id}
app.MapControllerRoute(
    name: "products",
    pattern: "Products/{category}/{id:int}",
    defaults: new { controller = "Products", action = "Details" }
);

// Complex route: /Users/{username}/Orders
app.MapControllerRoute(
    name: "userOrders",
    pattern: "Users/{username}/Orders",
    defaults: new { controller = "Users", action = "Orders" }
);

// Custom GUID constraint (built-in :guid OR our custom :myguid)
app.MapControllerRoute(
    name: "guidExample",
    pattern: "Products/Guid/{id:myguid}",
    defaults: new { controller = "Products", action = "GuidExample" }
);

// Default conventional route
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}"
);

app.Run();