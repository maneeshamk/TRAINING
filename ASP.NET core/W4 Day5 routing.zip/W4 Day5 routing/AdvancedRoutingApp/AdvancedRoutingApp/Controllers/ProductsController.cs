using Microsoft.AspNetCore.Mvc;

namespace AdvancedRoutingApp.Controllers
{
    public class ProductsController : Controller
    {
        // /Products/{category}/{id}
        public IActionResult Details(string category, int id)
        {
            ViewBag.Category = category;
            ViewBag.Id = id;
            return View();
        }

        // /Products/Guid/{id}
        public IActionResult GuidExample(Guid id)
        {
            ViewBag.Guid = id;
            return View();
        }
    }
}