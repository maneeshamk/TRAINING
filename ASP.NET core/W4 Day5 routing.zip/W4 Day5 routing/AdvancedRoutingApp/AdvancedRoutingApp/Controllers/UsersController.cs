using Microsoft.AspNetCore.Mvc;

namespace AdvancedRoutingApp.Controllers
{
    public class UsersController : Controller
    {
        // /Users/{username}/Orders
        public IActionResult Orders(string username)
        {
            ViewBag.Username = username;
            return View();
        }
    }
}