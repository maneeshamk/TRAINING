import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CourseList } from './course-list/course-list';
import { CourseDetail } from './course-detail/course-detail';

export interface Course {
  id: number;
  title: string;
  description: string;
}

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, CourseList, CourseDetail],
  templateUrl: './app.html',
  styleUrls: ['./app.css']
})
export class App {
  courses: Course[] = [
    { id: 1, title: 'Angular Basics', description: 'Intro to Angular.' },
    { id: 2, title: 'RxJS Mastery', description: 'Reactive programming.' },
    { id: 3, title: 'Standalone Components', description: 'Modular Angular.' }
  ];

  selectedCourse: Course | null = null;

  onCourseSelected(course: Course) {
    this.selectedCourse = { ...course };
  }

  onCourseUpdated(updated: any) {
  console.log('Course updated:', updated);
  this.selectedCourse = updated;
}
}