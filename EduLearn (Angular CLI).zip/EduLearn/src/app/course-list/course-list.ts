import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Course } from '../app';

@Component({
  selector: 'app-course-list',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './course-list.html',
  styleUrls: ['./course-list.css']
})
export class CourseList {
  @Input() courses: Course[] = [];
  @Output() selectCourse = new EventEmitter<Course>();

  onSelect(course: Course) {
    this.selectCourse.emit(course);
  }
}