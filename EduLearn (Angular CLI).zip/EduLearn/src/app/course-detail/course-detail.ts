import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Course } from '../app';

@Component({
  selector: 'app-course-detail',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './course-detail.html',
  styleUrls: ['./course-detail.css']
})
export class CourseDetail {
  @Input() course!: Course;
  @Output() courseChange = new EventEmitter<Course>();

  updateTitle() {
    console.log('Title updated to:', this.course.title);
    this.courseChange.emit({ ...this.course });
  }
}