# Install Dependencies
npm install

# Run Application
ng serve  
### The development server at http://localhost:4200/


# Property Binding ([property]) : Used to bind the value of HTML elements or component inputs to a property in your class.
# Example: <input [value]="course.title" />   This sets the input’s value based on course.title. It’s one-way—from component to view.

# Event Binding ((event)) : Used to respond to user actions like clicks or input changes.
# Example: <button (click)="updateTitle()">Update</button>    When the button is clicked, it triggers the updateTitle() method in your component. This is one-way—from view to component.

# Two-Way Binding ([(ngModel)]) : Used on the input field to keep course.title in sync with the user’s input.
# Example: <input [(ngModel)]="course.title" /> This creates a two-way data flow: - When the user types, course.title updates
# - When course.title changes in code, the input reflects it